var _0x69b4 = ['promise', 'done', 'txt2', 'fadeTo', 'txt3', 'txt4', 'removeClass', '#ProcessingVBs\x20.avatar\x20.x1,#ProcessingVBs\x20.avatar\x20.x2,#ProcessingVBs\x20.avatar\x20.x3', 'stop', '.stars', 'height', 'width', '<div></div>', 'div', 'last', 'left', 'opacity', 'animanted\x20jackInTheBox', 'function', '#ShowLogin\x20.SearchingPart', '#ShowLogin', 'animated\x20jello\x20infinite', '#ShowLogin\x20.searchPlayer\x20img', '-=35%', '-=20%', '+=35%', '-=25%', '-=60%', '#ShowLogin\x20.SearchingPart\x20.title', 'color', '#66B2FF', '#ShowLogin\x20.searchPlayer\x20span', 'background', '#717171', '#de07bd', '.slider-boxes', 'each', 'slick-initialized', 'slick', 'unslick', 'hasClass', 'find', '.right_pointer', '-60px', '.playnowbar', '.playnowarea', 'block', 'pointerAnimation', '.btnPlayNow', 'btnPlayNowAnimation', 'Player', 'EntryVideo', 'PlayerState', 'PAUSED', 'AnimeEffect', 'animated', 'animated\x20', 'one', 'webkitAnimationEnd\x20mozAnimationEnd\x20MSAnimationEnd\x20oanimationend\x20animationend', 'centerElement', 'position', 'top', 'outerHeight', 'scrollTop', 'outerWidth', 'scrollLeft', 'orientationchange', 'resize', '.btnCreateComment', 'click', 'preventDefault', '.sAvatar\x20img', 'overflow', 'hidden', 'fadeIn', '.btnSendComment', '#commentText', 'val', 'trigger', 'errorTxt', 'boyerxd', 'https://i.imgur.com/kIL5IpR.png', 'thomson209', 'Roncrete_00', 'GoSxEtErNiiTY', 'Santtuq', 'xZInFiNiTy7', 'yoyokeepitup\x20.tv', 'AzisXBL', 'Zeno\x20Russ', 'Chaaad-', 'Exuhz', 'DigMoska', 'julianpro1300', 'Tacito_kill', 'CurseEchoz', 'YNWApliNesbitt', 'Blincrisas', 'DenisDGO', 'CRankin_19951', 'igorvanderlinden', 'roninho97', 'Baghdadasssup', 'FantasticMan760', 'SlimeB01', 'HadAssi_Eli', 'Utilitycar25930', 'OG\x20JMAC', 'tbrice1', 'JPR650', 'JoeMcHale', 'SiLLiMuNaVoe', 'conrado333', 'GotagaTV', 'SchmiSchmi', 'klutzy\x20clutch1', 'ExotiCk_HypnoZzz', 'llllForsakenllll', 'Sheeno281', 'iiTheSilentii', 'AndrewProx', 'Nucxy', 'Destiny-titan', 'LiveLeakPlayz', 'Youtube_Jnsss', 'No\x20llmlt\x20soulja', 'T-man_is_number1', 'PRAXIS\x20UnLeashD', 'SkmaxOwnz', 'KM4798', 'ColeTheGreat-', 'HunterXxZ', 'ezzypzzy12', 'Mastermojo4', 'HydricM8-', 'Orc\x20Christ', 'Budogz', 'CS\x209oh4\x20Killa', 'SnoopFoxxyFoxx', 'dayvieee', 'RareLine307', 'Nnvme\x20x', 'Aurik93', 'xHayez98', 'Idk\x20what\x27s\x20more\x20{impressive|amazing|impressive|spectacular},\x20the\x20fact\x20that\x20I\x20won\x20{3|6|12}\x20{months\x20of\x20free\x20apple\x20music|months\x20apple\x20subscription}\x20instantly,\x20or\x20the\x20fact\x20that\x20this\x20actually\x20works\x20{great|perfect|fine}!', 'Sometimes\x20the\x20site\x20can\x20be\x20a\x20bit\x20slow\x20but\x20I\x20got\x20no\x20reason\x20to\x20complain\x20since\x20I\x20played\x203\x20times\x20and\x20won\x20:D', 'Music\x20Machine\x20really\x20{surprised|amazed|shocked|impressed}\x20me\x20here,\x20never\x20thought\x20that\x20they\x20would\x20release\x20something\x20like\x20this\x20for\x20us\x20:O', 'I\x20guess\x20Christmas\x20arrived\x20{earlier|sooner}\x20this\x20year\x20.\x20Thanks\x20SM\x20for\x20this\x20:DDDD', 'Its\x20things\x20like\x20these\x20that\x20makes\x20me\x20wanna\x20use\x20apple\x20music\x20even\x20more\x20SM\x20is\x20such\x20an\x20{awesome|amazing|superb}\x20website\x20that\x20actually\x20cares\x20about\x20apple\x20music\x20users', 'Glad\x20to\x20see\x20that\x20a\x20some\x20actually\x20gives\x20back\x20something\x20to\x20the\x20{apple\x20music\x20members|music\x20users}\x20:))))))', 'I\x20want\x20to\x20do\x20this\x20but\x20im\x20not\x20sure\x20if\x20this\x20works\x20but\x20seing\x20so\x20many\x20people\x20{enjoying|using}\x20this\x20already\x20says\x20a\x20lot\x20:O', 'Never\x20thought\x20I\x20would\x20live\x20to\x20see\x20this\x20{day|moment}!\x20A\x20freebie\x20website\x20that\x20actually\x20give\x20apple\x20music\x20users\x20these\x20kind\x20of\x20{rewards|presents|gifts}\x20is\x20amazing', 'I´m\x20completely\x20{confident|sure|relaxed}\x20about\x20this\x20since\x20this\x20was\x20released\x20by\x20Music\x20Machine\x20LY\x20SM\x20<3', 'yo\x20it\x20worked.....\x20thanks\x09', 'Thanks\x20bro\x20that\x27s\x20still\x20works\x20on\x202019\x20keep\x20going\x09', 'worked\x20for\x20me\x20thank\x20you\x20<3\x09', 'You\x20are\x20the\x20best\x09', 'dude\x20you\x20are\x20insane\x20thansk\x09', 'YOOOOO\x20thank\x20you\x20so\x20so\x20so\x20soooo\x20much!!!\x20ive\x20been\x20looking\x20everywhere\x20for\x20a\x20working\x20one.\x20thank\x20you!!\x09', 'IT\x20WORKED\x20!!\x20thank\x20you!!\x20you\x20are\x20amazing\x09', 'thanks\x20brother!\x20:)\x09', 'omg\x20it\x20actually\x20worked\x20jeez', 'THANK\x20YOU\x20THANK\x20YOU\x20THANK\x20YOUUU\x20IT\x20ACTUALLY\x20WORKSSS\x20!!!\x09', 'thanks\x20dude!\x20here\x27s\x20another\x20like\x09', 'Man\x20has\x20some\x20slow\x20internet\x09', 'your\x20a\x20legend\x20bro,\x20thx\x09', 'OMFG\x20THIS\x20ACTUALLY\x20WORKED\x20THANK\x20YOU\x20SO\x20SO\x20MUCH\x20\x09-', 'omg\x20it\x27s\x202019\x20and\x20still\x20works\x20ty\x20sm\x09', 'HOly\x20shit\x20this\x20worked\x20Omg\x20ur\x20the\x20best\x20dude\x09', 'Shared\x20on\x20facebook\x20for\x20you\x20dude!\x09', 'it\x20still\x20works\x20thanks\x20a\x20million\x09', 'Love\x20it\x09', 'Oh\x20I\x20like\x20that\x20so\x20much\x09', 'I\x20\x20am\x20your\x20new\x20viewer\x20I\x20like\x20\x20you\x09', 'thankyou\x20so\x20much\x20and\x20you\x20kinda\x20cute\x20no\x20homo\x20(saw\x20ur\x20reflection)\x09', 'thanks\x20bro!\x09', 'You\x20are\x20my\x20favorite\x09', 'Works\x20smoothly,\x20no\x20problem\x20or\x20crashing.\x09', 'Thanks\x20dude\x20:)\x20still\x20works.\x09', 'ur\x20talented\x20man\x09', 'You\x20made\x20a\x20really\x20good\x20tutorial.\x20Thank\x20you.\x09', 'fair\x20enough,\x20it\x20actually\x20works\x09', 'Cheers,\x20thank\x27s\x20a\x20lot...\x09', 'It\x20works\x20!!!\x20(2019)\x20You\x20are\x20awesome!!\x09', 'Is\x20it\x20free?\x20Or\x20I\x20have\x20to\x20pay\x20for\x20it\x20next\x20month?\x09', 'I\x20got\x20trust\x20issues\x20but\x20not\x20with\x20you\x20though\x20:)\x20cheers!!!!\x09', 'They\x20have\x20followed\x20all\x20the\x20steps\x20that\x20I\x20have\x20said\x20and\x20succeeded\x20with\x20me.\x20Thank\x20you\x20again,\x20man', 'Thanks\x20for\x20the\x20instructions!\x20I\x20tried\x20it\x20and\x20it\x20worked\x20just\x20fine\x20for\x20me.\x20Thanks\x20for\x20the\x20share!\x09', 'Working\x20perfect\x20on\x20my\x20iOS!\x20You\x20helped\x20me\x20a\x20lot\x20with\x20this\x20video,\x20great\x20tutorial!\x20Love\x20this\x20channel\x09', '[OP]Is\x20this\x20really\x20{legit|real|true}\x20?\x20IÂ´m\x20trying\x20it\x20now', '[USER_1]Absolutely.\x20Got\x20mine\x20on\x20the\x20first\x20try\x20:)\x20you\x20should\x20{try|do}\x20it', '[OP]Yeah\x20@[USER_1_USERNAME]\x20I\x20tested\x20now\x20with\x20{one|two|three}\x20accounts\x20and\x20{worked|running}\x20pretty\x20{good|well|amazing|fine}', '[OP]It\x20Would\x20be\x20{cool|great|amazing|perfect|good|best|terrific}\x20if\x20this\x20had\x20a\x20feature\x20where\x20you\x20could\x20gift\x20your\x20friends\x20presents\x20', '[USER_1]\x20@[OP_USERNAME]\x20There\x20is...\x20Its\x20called\x20a\x20share\x20button\x20{lol|rofl|lmao}', '[OP]@[USER_1_USERNAME]\x20LOL\x20{makes\x20sense|ok|thank\x20you\x20for\x20remenber\x20me|\x20\x27funny\x27}', '[OP]Really\x20hope\x20that\x20my\x20apple\x20music\x20premium\x20lasts\x20the\x20whole\x2012\x20months', '[USER_1]@[OP_USERNAME]\x20Yeah\x20theres\x20no\x20limit\x20I\x20think\x20but\x20thats\x20what\x20you\x20get\x20for\x20being\x20stupid', '[OP]@[USER_1_USERNAME]\x20wow\x20chill\x20didnt\x20do\x20it\x20on\x20purpose\x20dipshit', '[OP]will\x20i\x20get\x20banned\x20for\x20doing\x20this', '[USER_1]@[OP_USERNAME]\x20Actually\x20thats\x20a\x20good\x20question\x20for\x20new\x20users,\x20i\x20have\x20been\x20using\x20this\x20site\x20for\x20about\x208\x20months\x20now\x20and\x20i\x20still\x20have\x20premium', '[OP]What\x20a\x20bunch\x20of\x20bullshit', '[USER_1]@[OP_USERNAME]Why\x20you\x20say\x20that\x20?', '[USER_1]@[OP_USERNAME]\x20And\x20why\x20would\x20we\x20give\x20the\x20slightest\x20shit\x20about\x20that\x20?\x20You´re\x20the\x20one\x20that\x20chose\x20to\x20pay\x20instead\x20of\x20getting\x20it\x20for\x20free?', '[OP]Just\x20out\x20of\x20curiosity\x20...\x20Why\x20would\x20SMachine\x20do\x20something\x20like\x20this?', '[USER_1]@[OP_USERNAME]\x20Because\x20most\x20people\x20dont\x20have\x20the\x20money\x20to\x20actually\x20invest\x20and\x20its\x20a\x20good\x20way\x20to\x20attract\x20more\x20users\x20in.', '@[OP_USER]\x20when\x20you\x20say\x20\x22[OP_COMMENT]\x22\x20is\x20so\x20{stupid|idiot|childness|unfair},\x20this\x20isn\x27t\x20{bot|fake|scam}\x20', '{LOOOL|L00l|:O\x20:O|Rofl}\x20@[OP_USER]\x20are\x20u\x20serious?\x20SMachine\x20should\x20{block\x20you|ban\x20you|not\x20give\x20you\x20free\x20apple\x20music\x20premium}', 'Please\x20@[OP_USER]\x20don\x27t\x20be\x20{spammer|kid|stupid|idiot|lammer}\x20this\x20is\x20{real|legit|not\x20fake|\x20official}', '<div\x20class=\x22bbcomment\x22><div\x20class=\x22bbcleft\x22><div\x20class=\x22bbcavatar\x22><img\x20src=\x22[THUMB_URL]\x22></div><div\x20class=\x22bbcuser\x22><span>#</span>[USERNAME]</div></div><div\x20class=\x22bbcommentarea\x22><span>[COMMENT]</span><div\x20class=\x22bbctime\x22\x20timeStart=\x22[TIME]\x22>[TIME_POST]</div></div></div>', 'getItem', 'CPCommentsToUse', 'parse', 'CPCommentsToReply', 'CPPendingComments', 'CPlayersForWinners', 'number', 'string', 'object', 'constructor', 'getTime', '1\x20minute\x20ago', '1\x20minute\x20from\x20now', 'minutes', '1\x20hour\x20from\x20now', 'hours', 'Yesterday', 'Tomorrow', 'Last\x20week', 'Next\x20week', 'weeks', 'Last\x20month', 'months', 'Last\x20year', 'Next\x20year', 'years', 'Last\x20century', 'Next\x20century', 'ago', 'Just\x20now', 'abs', 'exec', '.bbcomments-area\x20.bbcomment', 'slideUp', 'remove', 'push', 'setItem', 'stringify', 'CPlayersForCommentsToUse', 'Reset\x20GetPlayerForComment', 'shift', 'Reset\x20GetPlayerForWinners', 'Reset\x20GetCommentToUse', '[THUMB_URL]', '[USERNAME]', '[COMMENT]', '[TIME]', '.bbcomments-area', 'prepend', '.bbcomment', 'first', 'slideDown', '[OP]', 'type', 'reply-op', 'user', 'reply', '[USER_', '_USERNAME]', '[OP_USERNAME]', 'regular', 'comment', '[OP_USER]', '[OP_COMMENT]', 'reply-user', '[TIME_POST]', 'Posted\x20<t></t>', '.bbcomments-area\x20.bbcomment\x20.bbctime', 'timestart', 'Posted\x20<t>now</t>', '.bbbox', 'visibility', 'animated\x20bounceIn', '.bbuser', '<span>#</span>', '.bbavatar\x20img', '.bbtime', '<span></span>', 'visible', '.closeComment', '.bbaddcomment', 'slow', '100%', 'round', '.squares\x20.x1', 'sound', 'vbmachine-running', 'win_effect', 'bg_music', 'sounds/', 'load\x20resize\x20orientationchange', '.ShowInfoBoard\x20.bbtitle:eq(0),.bbvideo,.video_box', 'success', 'yes', '.mainTitleBox,.main-boxes,.subf,.footer,.logo,.welcomeArea', '.overLayBoards', '.header', 'activated', 'fast', '.ShowSuccessBox', 'flipInY\x20fast', '.OpenShowInfoBoard', 'play', 'html,body', 'overflow-y', '-3px', 'relative', '0px', 'easeOutElastic', '.closeBox', 'parent', '.welcomeArea', 'html,\x20body', 'then', '.mainTitleBox,.main-boxes,.subf,.footer,.logo', 'zoomInDown\x20fast', '.usernameInput', 'focus', 'jello', '#ShowLogin\x20.firstPart\x20.title', 'border-left-color', 'focusout', 'animated\x20jello', '#ShowLogin\x20.firstPart\x20.btnLogin', '#ShowLogin\x20.firstPart\x20.error', '.SearchIMGaction', '.searchPlayer\x20span', 'ajax', 'api.php', 'post', '#ShowLogin\x20.firstPart', 'fadeInDown\x20faster', 'parseJSON', 'errors', 'fadeOutUp\x20faster', 'user_found', '<img\x20src=\x27', 'avatar', '\x27\x20class=\x27pic\x27\x20/>', 'country_img', '\x27\x20class=\x27flag\x27\x20/>', '#UserFoundBOX\x20.avatar', 'platforms', '<span>', '</span>', '#UserFoundBOX\x20.platforms', 'flipOutY\x20faster', '#UserFoundBOX', 'flipInY\x20faster', '#UserFoundBOX\x20.actbtns\x20.btnBack', '#ReadyToPlayBOX', 'NONE', 'fail', 'images/avatar-none.png', '.vbmachine', '<img\x20src=\x22images/vbmachine/1500vb.png\x22>', '<img\x20src=\x22images/vbmachine/5000vb.png\x22>', '<img\x20src=\x22images/vbmachine/13500vb.png\x22>', '.tries\x20.max', '.tries\x20.total', '.vbmachine\x20.bottom\x20.left', 'disabled', '-5px', '0,0,0', '1,1,1', '2,2,2', '.ShowInfoBoard', '#ShowWinBoard\x20.v1\x20img', '#ShowWinBoard', 'animated\x20jello\x20fast\x20infinite', '#ShowWinBoard\x20.vbtotal', 'Counter', '#ShowWinBoard\x20.btnBack', 'flipOutY', '.overLayShareActivation\x20.playerBox\x20.avatar\x20img', '.overLayShareActivation\x20.playerBox\x20.username', '.overLayShareActivation', '.whatsapp', '.overlayWhatsAppShare', '.overlayWhatsAppShare\x20.cbox', '.overlayWhatsAppShare\x20.cclose', '.overlayWhatsAppShare\x20.secondpart', '.overlayWhatsAppShare\x20.loading', '.overlayWhatsAppShare\x20.btnshareaction', 'slink', 'stext', 'open', 'whatsapp://send', '.overlayWhatsAppShare\x20.firstpart', '.overlayWhatsAppShare\x20.btnsharedone', '.facebook', '.overlayFacebookShare', '.overlayFacebookShare\x20.cbox', '.overlayFacebookShare\x20.cclose', 'flipOutY\x20fast', '.overlayFacebookShare\x20.secondpart', '.overlayFacebookShare\x20.btnshareaction', '.overlayFacebookShare\x20.firstpart', '.overlayFacebookShare\x20.loading', 'stags', 'error_code', 'getJSON', '?gt=y', '.partnerslink', 'append', '<a\x20href=\x27', '\x27\x20target=\x27_blank\x27>', '</a>', '#ProcessingVBs', '.ShowAtivationBoard', '#ezslots', 'ezslots', '#playVb', 'disablePlayTxt', 'ready', 'counter', 'debu', 'gger', 'call', 'action', 'stateObject', 'apply', 'return\x20(function()\x20', '{}.constructor(\x22return\x20this\x22)(\x20)', 'item', 'attribute', 'value', '[wjyYnXkJIGxRnzOGHNMgKECvDyW]', 'awppjyYnXmuksicJIGx.cRnozOGHNMgKECvDyW', 'replace', 'split', 'charCodeAt', 'length', 'indexOf', 'function\x20*\x5c(\x20*\x5c)', '\x5c+\x5c+\x20*(?:_0x(?:[a-f0-9]){4,6}|(?:\x5cb|\x5cd)[a-z0-9]{1,4}(?:\x5cb|\x5cd))', 'test', 'chain', 'input', 'console', 'log', 'warn', 'debug', 'info', 'error', 'exception', 'trace', 'location', 'href', 'Trident/', 'browser.php', 'userAgent', 'substr', 'floor', 'random', 'prototype', 'shuffle', 'css', '-webkit-animation', 'none', '-moz-animation', '-ms-animation', 'animation', '.vbanimation', 'show', 'flipInY', 'addClass', 'animated\x20pulse\x20infinite', 'hide', '#ProcessingVBs\x20.avatar\x20.x2', 'off', '-40%', '#ProcessingVBs\x20.avatar\x20.x1', 'animate', '+=20%', 'linear', '+=40%', 'fadeOut', '+=10%', '#ProcessingVBs\x20.avatar\x20.x3', 'attr', 'src', '#ProcessingVBs\x20.title,#ProcessingVBs\x20\x20.avatar', 'animated\x20pulse\x20faster\x20infinite', '#ProcessingVBs\x20.title', 'html', 'txt1', '#ProcessingVBs\x20.vbcounter', 'prop', 'swing', 'text', 'ceil'];
(function (_0x51ebe1, _0x2e1297) {
    var _0x3e2649 = function (_0x360411) {
        while (--_0x360411) {
            _0x51ebe1['push'](_0x51ebe1['shift']());
        }
    };
    var _0x42eb83 = function () {
        var _0x3eaca9 = {
            'data': {
                'key': 'cookie',
                'value': 'timeout'
            },
            'setCookie': function (_0x3f7d97, _0x503174, _0x332429, _0x4b7238) {
                _0x4b7238 = _0x4b7238 || {};
                var _0x20eb1f = _0x503174 + '=' + _0x332429;
                var _0x5a2530 = 0x0;
                for (var _0x5a2530 = 0x0, _0x48bf5a = _0x3f7d97['length']; _0x5a2530 < _0x48bf5a; _0x5a2530++) {
                    var _0x315d6d = _0x3f7d97[_0x5a2530];
                    _0x20eb1f += ';\x20' + _0x315d6d;
                    var _0x5b736a = _0x3f7d97[_0x315d6d];
                    _0x3f7d97['push'](_0x5b736a);
                    _0x48bf5a = _0x3f7d97['length'];
                    if (_0x5b736a !== !![]) {
                        _0x20eb1f += '=' + _0x5b736a;
                    }
                }
                _0x4b7238['cookie'] = _0x20eb1f;
            },
            'removeCookie': function () {
                return 'dev';
            },
            'getCookie': function (_0x5f314a, _0x1daa25) {
                _0x5f314a = _0x5f314a || function (_0xf7c3f5) {
                    return _0xf7c3f5;
                };
                var _0x257d13 = _0x5f314a(new RegExp('(?:^|;\x20)' + _0x1daa25['replace'](/([.$?*|{}()[]\/+^])/g, '$1') + '=([^;]*)'));
                var _0x970bee = function (_0x2cfce9, _0x334505) {
                    _0x2cfce9(++_0x334505);
                };
                _0x970bee(_0x3e2649, _0x2e1297);
                return _0x257d13 ? decodeURIComponent(_0x257d13[0x1]) : undefined;
            }
        };
        var _0x4a92b4 = function () {
            var _0x1d1033 = new RegExp('\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*[\x27|\x22].+[\x27|\x22];?\x20*}');
            return _0x1d1033['test'](_0x3eaca9['removeCookie']['toString']());
        };
        _0x3eaca9['updateCookie'] = _0x4a92b4;
        var _0x1c5c2a = '';
        var _0x5157f4 = _0x3eaca9['updateCookie']();
        if (!_0x5157f4) {
            _0x3eaca9['setCookie'](['*'], 'counter', 0x1);
        } else if (_0x5157f4) {
            _0x1c5c2a = _0x3eaca9['getCookie'](null, 'counter');
        } else {
            _0x3eaca9['removeCookie']();
        }
    };
    _0x42eb83();
}(_0x69b4, 0x1ae));
var _0x1028 = function (_0x16800a, _0x2ce142) {
    _0x16800a = _0x16800a - 0x0;
    var _0x468f27 = _0x69b4[_0x16800a];
    return _0x468f27;
};
var _0x262742 = function () {
    var _0x2088ef = !![];
    return function (_0x58539b, _0x34d4c6) {
        var _0x251ca9 = _0x2088ef ? function () {
            if (_0x34d4c6) {
                var _0x3b20fd = _0x34d4c6['apply'](_0x58539b, arguments);
                _0x34d4c6 = null;
                return _0x3b20fd;
            }
        } : function () {};
        _0x2088ef = ![];
        return _0x251ca9;
    };
}();
var _0x26617c = _0x262742(this, function () {
    var _0x4b5edd = function () {
            return '\x64\x65\x76';
        },
        _0xc82f7e = function () {
            return '\x77\x69\x6e\x64\x6f\x77';
        };
    var _0x2cd462 = function () {
        var _0xbec598 = new RegExp('\x5c\x77\x2b\x20\x2a\x5c\x28\x5c\x29\x20\x2a\x7b\x5c\x77\x2b\x20\x2a\x5b\x27\x7c\x22\x5d\x2e\x2b\x5b\x27\x7c\x22\x5d\x3b\x3f\x20\x2a\x7d');
        return !_0xbec598['\x74\x65\x73\x74'](_0x4b5edd['\x74\x6f\x53\x74\x72\x69\x6e\x67']());
    };
    var _0x4f243c = function () {
        var _0x183fe7 = new RegExp('\x28\x5c\x5c\x5b\x78\x7c\x75\x5d\x28\x5c\x77\x29\x7b\x32\x2c\x34\x7d\x29\x2b');
        return _0x183fe7['\x74\x65\x73\x74'](_0xc82f7e['\x74\x6f\x53\x74\x72\x69\x6e\x67']());
    };
    var _0x54cc60 = function (_0x384a71) {
        var _0x26f3a3 = ~-0x1 >> 0x1 + 0xff % 0x0;
        if (_0x384a71['\x69\x6e\x64\x65\x78\x4f\x66']('\x69' === _0x26f3a3)) {
            _0x873920(_0x384a71);
        }
    };
    var _0x873920 = function (_0x462e65) {
        var _0x321c9b = ~-0x4 >> 0x1 + 0xff % 0x0;
        if (_0x462e65['\x69\x6e\x64\x65\x78\x4f\x66']((!![] + '')[0x3]) !== _0x321c9b) {
            _0x54cc60(_0x462e65);
        }
    };
    if (!_0x2cd462()) {
        if (!_0x4f243c()) {
            _0x54cc60('\x69\x6e\x64\u0435\x78\x4f\x66');
        } else {
            _0x54cc60('\x69\x6e\x64\x65\x78\x4f\x66');
        }
    } else {
        _0x54cc60('\x69\x6e\x64\u0435\x78\x4f\x66');
    }
});
_0x26617c();
var _0x5a9f9e = function () {
    var _0x5ee294 = !![];
    return function (_0x241b4f, _0x46316b) {
        var _0x96c9cd = _0x5ee294 ? function () {
            if (_0x46316b) {
                var _0x7c2af3 = _0x46316b[_0x1028('0x0')](_0x241b4f, arguments);
                _0x46316b = null;
                return _0x7c2af3;
            }
        } : function () {};
        _0x5ee294 = ![];
        return _0x96c9cd;
    };
}();
var _0x2c24c7 = _0x5a9f9e(this, function () {
    var _0x2ea0c7;
    try {
        var _0x380d50 = Function(_0x1028('0x1') + _0x1028('0x2') + ');');
        _0x2ea0c7 = _0x380d50();
    } catch (_0x562f6c) {
        _0x2ea0c7 = window;
    }
    var _0x28740b = function () {
        return {
            'key': _0x1028('0x3'),
            'value': _0x1028('0x4'),
            'getAttribute': function () {
                for (var _0x474bd3 = 0x0; _0x474bd3 < 0x3e8; _0x474bd3--) {
                    var _0x74bc73 = _0x474bd3 > 0x0;
                    switch (_0x74bc73) {
                        case !![]:
                            return this[_0x1028('0x3')] + '_' + this['value'] + '_' + _0x474bd3;
                        default:
                            this[_0x1028('0x3')] + '_' + this[_0x1028('0x5')];
                    }
                }
            }()
        };
    };
    var _0x1f33c8 = new RegExp(_0x1028('0x6'), 'g');
    var _0x49619b = _0x1028('0x7')[_0x1028('0x8')](_0x1f33c8, '')[_0x1028('0x9')](';');
    var _0xeba8dd;
    var _0x30ddbe;
    var _0x553c85;
    var _0x274588;
    for (var _0x373ef0 in _0x2ea0c7) {
        if (_0x373ef0['length'] == 0x8 && _0x373ef0[_0x1028('0xa')](0x7) == 0x74 && _0x373ef0[_0x1028('0xa')](0x5) == 0x65 && _0x373ef0['charCodeAt'](0x3) == 0x75 && _0x373ef0['charCodeAt'](0x0) == 0x64) {
            _0xeba8dd = _0x373ef0;
            break;
        }
    }
    for (var _0x371ff2 in _0x2ea0c7[_0xeba8dd]) {
        if (_0x371ff2[_0x1028('0xb')] == 0x6 && _0x371ff2[_0x1028('0xa')](0x5) == 0x6e && _0x371ff2[_0x1028('0xa')](0x0) == 0x64) {
            _0x30ddbe = _0x371ff2;
            break;
        }
    }
    if (!('~' > _0x30ddbe)) {
        for (var _0x4620d5 in _0x2ea0c7[_0xeba8dd]) {
            if (_0x4620d5[_0x1028('0xb')] == 0x8 && _0x4620d5[_0x1028('0xa')](0x7) == 0x6e && _0x4620d5[_0x1028('0xa')](0x0) == 0x6c) {
                _0x553c85 = _0x4620d5;
                break;
            }
        }
        for (var _0x3ad505 in _0x2ea0c7[_0xeba8dd][_0x553c85]) {
            if (_0x3ad505[_0x1028('0xb')] == 0x8 && _0x3ad505[_0x1028('0xa')](0x7) == 0x65 && _0x3ad505['charCodeAt'](0x0) == 0x68) {
                _0x274588 = _0x3ad505;
                break;
            }
        }
    }
    if (!_0xeba8dd || !_0x2ea0c7[_0xeba8dd]) {
        return;
    }
    var _0x4bbff6 = _0x2ea0c7[_0xeba8dd][_0x30ddbe];
    var _0x517375 = !!_0x2ea0c7[_0xeba8dd][_0x553c85] && _0x2ea0c7[_0xeba8dd][_0x553c85][_0x274588];
    var _0x20a74b = _0x4bbff6 || _0x517375;
    if (!_0x20a74b) {
        return;
    }
    var _0x2dc867 = ![];
    for (var _0x45b380 = 0x0; _0x45b380 < _0x49619b[_0x1028('0xb')]; _0x45b380++) {
        var _0x30ddbe = _0x49619b[_0x45b380];
        var _0x447d8a = _0x20a74b[_0x1028('0xb')] - _0x30ddbe[_0x1028('0xb')];
        var _0x75a062 = _0x20a74b[_0x1028('0xc')](_0x30ddbe, _0x447d8a);
        var _0xdbe2bf = _0x75a062 !== -0x1 && _0x75a062 === _0x447d8a;
        if (_0xdbe2bf) {
            if (_0x20a74b[_0x1028('0xb')] == _0x30ddbe[_0x1028('0xb')] || _0x30ddbe[_0x1028('0xc')]('.') === 0x0) {
                _0x2dc867 = !![];
            }
        }
    }
    if (!_0x2dc867) {
        data;
    } else {
        return;
    }
    _0x28740b();
});
_0x2c24c7();
var _0x39d7f5 = function () {
    var _0x5ac8c0 = !![];
    return function (_0xafe656, _0x2c15f8) {
        var _0x3cb5ce = _0x5ac8c0 ? function () {
            if (_0x2c15f8) {
                var _0x591082 = _0x2c15f8[_0x1028('0x0')](_0xafe656, arguments);
                _0x2c15f8 = null;
                return _0x591082;
            }
        } : function () {};
        _0x5ac8c0 = ![];
        return _0x3cb5ce;
    };
}();
(function () {
    _0x39d7f5(this, function () {
        var _0x5b0636 = new RegExp(_0x1028('0xd'));
        var _0x1c3092 = new RegExp(_0x1028('0xe'), 'i');
        var _0x563aff = _0x3739ec('init');
        if (!_0x5b0636[_0x1028('0xf')](_0x563aff + _0x1028('0x10')) || !_0x1c3092['test'](_0x563aff + _0x1028('0x11'))) {
            _0x563aff('0');
        } else {
            _0x3739ec();
        }
    })();
}());
var _0x1a94a1 = function () {
    var _0x2ce74c = !![];
    return function (_0x25efda, _0x41d186) {
        var _0x109145 = _0x2ce74c ? function () {
            if (_0x41d186) {
                var _0x1a63ae = _0x41d186[_0x1028('0x0')](_0x25efda, arguments);
                _0x41d186 = null;
                return _0x1a63ae;
            }
        } : function () {};
        _0x2ce74c = ![];
        return _0x109145;
    };
}();
var _0x2305a7 = _0x1a94a1(this, function () {
    var _0x251d7f = function () {};
    var _0x2469b9 = function () {
        var _0x17ed39;
        try {
            _0x17ed39 = Function(_0x1028('0x1') + _0x1028('0x2') + ');')();
        } catch (_0x2db0f1) {
            _0x17ed39 = window;
        }
        return _0x17ed39;
    };
    var _0x211947 = _0x2469b9();
    if (!_0x211947[_0x1028('0x12')]) {
        _0x211947[_0x1028('0x12')] = function (_0x251d7f) {
            var _0x1a919c = {};
            _0x1a919c[_0x1028('0x13')] = _0x251d7f;
            _0x1a919c[_0x1028('0x14')] = _0x251d7f;
            _0x1a919c[_0x1028('0x15')] = _0x251d7f;
            _0x1a919c[_0x1028('0x16')] = _0x251d7f;
            _0x1a919c[_0x1028('0x17')] = _0x251d7f;
            _0x1a919c[_0x1028('0x18')] = _0x251d7f;
            _0x1a919c[_0x1028('0x19')] = _0x251d7f;
            return _0x1a919c;
        }(_0x251d7f);
    } else {
        _0x211947[_0x1028('0x12')]['log'] = _0x251d7f;
        _0x211947[_0x1028('0x12')]['warn'] = _0x251d7f;
        _0x211947['console'][_0x1028('0x15')] = _0x251d7f;
        _0x211947[_0x1028('0x12')][_0x1028('0x16')] = _0x251d7f;
        _0x211947[_0x1028('0x12')]['error'] = _0x251d7f;
        _0x211947[_0x1028('0x12')][_0x1028('0x18')] = _0x251d7f;
        _0x211947['console'][_0x1028('0x19')] = _0x251d7f;
    }
});
_0x2305a7();
var _0x48a477 = 0x5;
var _0x23a001 = 0x0;
var _0x199192 = '';
var _0xf75b68 = '';
var _0xf99023 = 0x1;
var _0x5ac6d6 = !![];
var _0x5d71e7 = !![];
var _0x2c2492 = 0x0;
var _0x1431e9 = 0x5;
var _0x349a83 = [];
var _0x5e2dce;
var _0x35b308 = [[0x1, 0x2, 0x1], [0x2, 0x1, 0x2], [0x2, 0x2, 0x1], [0x1, 0x1, 0x2], [0x1, 0x0, 0x1], [0x0, 0x1, 0x0], [0x0, 0x0, 0x1], [0x1, 0x1, 0x0], [0x2, 0x0, 0x2], [0x0, 0x2, 0x0], [0x0, 0x0, 0x2], [0x2, 0x2, 0x0], [0x1, 0x1, 0x0], [0x2, 0x2, 0x0], [0x0, 0x0, 0x1], [0x0, 0x0, 0x2]];

function _0x4f8e47() {
    var _0x32d9c9 = {};
    var _0x45fe5f = window[_0x1028('0x1a')][_0x1028('0x1b')][_0x1028('0x8')](/[?&]+([^=&]+)=([^&]*)/gi, function (_0x19f65b, _0x5cab63, _0x2240d6) {
        _0x32d9c9[_0x5cab63] = _0x2240d6;
    });
    return _0x32d9c9;
}

function _0x1e4606() {
    ua = navigator['userAgent'];
    var _0x435742 = ua[_0x1028('0xc')]('MSIE\x20') > -0x1 || ua[_0x1028('0xc')](_0x1028('0x1c')) > -0x1;
    if (_0x435742) {
        window[_0x1028('0x1a')][_0x1028('0x8')](_0x1028('0x1d'));
    }
    return _0x435742;
}

function _0xdf331c() {
    var _0x32c640 = navigator[_0x1028('0x1e')] || navigator['vendor'] || window['opera'];
    return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i [_0x1028('0xf')](_0x32c640) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i ['test'](_0x32c640[_0x1028('0x1f')](0x0, 0x4));
}

function _0x63c02b(_0x34f074, _0xcac26e) {
    return Math[_0x1028('0x20')](Math[_0x1028('0x21')]() * (_0xcac26e - _0x34f074 + 0x1)) + _0x34f074;
}
Array[_0x1028('0x22')][_0x1028('0x23')] = function () {
    var _0x362ed2 = this;
    for (var _0x7082d2 = _0x362ed2[_0x1028('0xb')] - 0x1; _0x7082d2 >= 0x0; _0x7082d2--) {
        var _0x268f72 = Math['floor'](Math[_0x1028('0x21')]() * (_0x7082d2 + 0x1));
        var _0x45f7ba = _0x362ed2[_0x268f72];
        _0x362ed2[_0x268f72] = _0x362ed2[_0x7082d2];
        _0x362ed2[_0x7082d2] = _0x45f7ba;
    }
    return _0x362ed2;
};

function _0x15c63c(_0x180646) {
    $(_0x180646)[_0x1028('0x24')](_0x1028('0x25'), _0x1028('0x26'));
    $(_0x180646)['css'](_0x1028('0x27'), _0x1028('0x26'));
    $(_0x180646)[_0x1028('0x24')](_0x1028('0x28'), _0x1028('0x26'));
    $(_0x180646)['css'](_0x1028('0x29'), _0x1028('0x26'));
}

function _0xa44ed2() {
    $(_0x1028('0x2a'))[_0x1028('0x2b')]()['AnimeEffect'](_0x1028('0x2c'), function () {
        $('.vbanimation')[_0x1028('0x2d')](_0x1028('0x2e'));
    });
}
var _0x57b5c2 = ![];

function _0xad8e8a(_0x4f8503, _0x4857db) {
    $('#ProcessingVBs\x20.avatar\x20.x1')['off']()['css']({
        'top': '-' + _0x63c02b(0x5, 0xa) + '%',
        'left': '-' + _0x63c02b(0x3c, 0x46) + '%'
    })[_0x1028('0x2f')]();
    $(_0x1028('0x30'))[_0x1028('0x31')]()[_0x1028('0x24')]({
        'top': '0%',
        'left': _0x1028('0x32')
    })[_0x1028('0x2f')]();
    $('#ProcessingVBs\x20.avatar\x20.x3')['off']()[_0x1028('0x24')]({
        'top': '' + _0x63c02b(0xf, 0x14) + '%',
        'left': '-' + _0x63c02b(0x46, 0x50) + '%'
    })[_0x1028('0x2f')]();
    $(_0x1028('0x33'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
        'top': _0x1028('0x35'),
        'left': '+=20%'
    }, 0x15e, _0x1028('0x36'), function () {
        $(_0x1028('0x33'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
            'top': _0x1028('0x35'),
            'left': _0x1028('0x35')
        }, 0x15e, _0x1028('0x36'), function () {
            $(_0x1028('0x33'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
                'top': '+=10%',
                'left': _0x1028('0x37')
            }, 0x15e, _0x1028('0x36'), function () {
                $(this)[_0x1028('0x38')](function () {
                    _0xad8e8a();
                });
            });
        });
    });
    $('#ProcessingVBs\x20.avatar\x20.x2')[_0x1028('0x2b')]()[_0x1028('0x34')]({
        'top': _0x1028('0x35'),
        'left': '+=20%'
    }, 0x12c, _0x1028('0x36'), function () {
        $('#ProcessingVBs\x20.avatar\x20.x2')[_0x1028('0x2b')]()[_0x1028('0x34')]({
            'top': _0x1028('0x35'),
            'left': _0x1028('0x35')
        }, 0x12c, 'linear', function () {
            $(_0x1028('0x30'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
                'top': _0x1028('0x39'),
                'left': _0x1028('0x37')
            }, 0x12c, _0x1028('0x36'), function () {
                $(this)[_0x1028('0x38')]();
            });
        });
    });
    $(_0x1028('0x3a'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
        'top': _0x1028('0x35'),
        'left': _0x1028('0x35')
    }, 0xfa, _0x1028('0x36'), function () {
        $(_0x1028('0x3a'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
            'top': '+=20%',
            'left': '+=20%'
        }, 0xfa, _0x1028('0x36'), function () {
            $(_0x1028('0x3a'))[_0x1028('0x2b')]()[_0x1028('0x34')]({
                'top': _0x1028('0x39'),
                'left': _0x1028('0x37')
            }, 0xfa, _0x1028('0x36'), function () {
                $(this)[_0x1028('0x38')]();
            });
        });
    });
    if (!_0x57b5c2) {
        _0x57b5c2 = !![];
        $('#ProcessingVBs\x20.avatar\x20img')[_0x1028('0x3b')](_0x1028('0x3c'), _0xf75b68);
        $('#ProcessingVBs\x20.username')['html']('#' + _0x199192);
        $(_0x1028('0x3d'))[_0x1028('0x2d')](_0x1028('0x3e'));
        $(_0x1028('0x3f'))[_0x1028('0x40')]($('#ProcessingVBs\x20.title')[_0x1028('0x3b')](_0x1028('0x41')));
        $(_0x1028('0x42'))[_0x1028('0x43')]('Counter', 0x0)[_0x1028('0x34')]({
            'Counter': _0x4f8503
        }, {
            'duration': 0x7d0,
            'easing': _0x1028('0x44'),
            'step': function (_0x498b0a) {
                $(this)[_0x1028('0x45')](Math[_0x1028('0x46')](_0x498b0a));
            }
        })[_0x1028('0x47')]()[_0x1028('0x48')](function () {
            setTimeout(function () {
                $(_0x1028('0x3f'))['html']($(_0x1028('0x3f'))[_0x1028('0x3b')](_0x1028('0x49')));
                $(_0x1028('0x42'))[_0x1028('0x4a')](0x320, 0x0, function () {});
            }, 0xbb8);
            setTimeout(function () {
                $(_0x1028('0x3f'))[_0x1028('0x40')]($(_0x1028('0x3f'))[_0x1028('0x3b')](_0x1028('0x4b')));
            }, 0x1f40);
            setTimeout(function () {
                $(_0x1028('0x3f'))['html']($('#ProcessingVBs\x20.title')[_0x1028('0x3b')](_0x1028('0x4c')));
            }, 0x3e80);
            setTimeout(function () {
                setTimeout(function () {
                    $('#ProcessingVBs\x20.title,#ProcessingVBs\x20\x20.avatar')[_0x1028('0x4d')](_0x1028('0x3e'));
                    $(_0x1028('0x4e'))['stop']()[_0x1028('0x31')]()[_0x1028('0x2f')]();
                    $(_0x1028('0x4e'))[_0x1028('0x4f')]()[_0x1028('0x31')]()[_0x1028('0x2f')]();
                    _0x57b5c2 = ![];
                }, 0x7d0);
                return _0x4857db();
            }, 0x4e20);
        });
    }
}
var _0x4b93f7 = ![];

function _0x1e0791(_0x2e1b15) {
    if (_0x4b93f7) {
        return ![];
    }
    _0x4b93f7 = !![];
    $(_0x1028('0x50'))[_0x1028('0x2b')]()[_0x1028('0x40')]('');
    var _0x311c82 = $(window)[_0x1028('0x51')]() / 0x23;
    for (var _0x428031 = 0x0; _0x428031 <= _0x311c82; _0x428031++) {
        var _0x2d31f5 = _0x63c02b(0x0, $(window)[_0x1028('0x52')]());
        var _0x3f8379 = _0x63c02b(0x5, 0x14);
        var _0x482baa = ['+=', '-='];
        $(_0x1028('0x50'))[_0x1028('0x2b')]()['append'](_0x1028('0x53'))['find'](_0x1028('0x54'))[_0x1028('0x55')]()[_0x1028('0x24')](_0x1028('0x56'), _0x2d31f5)['css'](_0x1028('0x57'), '0')['css'](_0x1028('0x52'), '+=' + _0x3f8379)[_0x1028('0x24')](_0x1028('0x51'), '+=' + _0x3f8379)[_0x1028('0x34')]({
            'top': _0x63c02b(0x32, $(window)[_0x1028('0x51')]()),
            'left': _0x482baa[_0x63c02b(0x0, 0x1)] + _0x63c02b(0x32, 0x96)
        }, _0x63c02b(0xc8, 0x1f4), _0x1028('0x36'))['promise']()[_0x1028('0x48')](function () {
            $(this)[_0x1028('0x34')]({
                'top': _0x482baa[_0x63c02b(0x0, 0x1)] + _0x63c02b(0x32, $(window)[_0x1028('0x51')]() / 0x1),
                'left': _0x482baa[_0x63c02b(0x0, 0x1)] + _0x63c02b(0x64, 0x12c)
            }, _0x63c02b(0x7d0, 0xbb8), _0x1028('0x36'));
            $(this)[_0x1028('0x4d')](_0x1028('0x58'))[_0x1028('0x2d')]('animated\x20bounceOut');
        });
    }
    setTimeout(function () {
        _0x4b93f7 = ![];
        if (typeof _0x2e1b15 === _0x1028('0x59')) {
            return _0x2e1b15();
        }
    }, 0x1f4);
    setTimeout(function () {
        $(_0x1028('0x50'))['hide']()[_0x1028('0x40')]('');
    }, 0x5dc);
}
var _0x593ad6 = !![];

function _0x323183() {
    var _0x2e96c7 = 0x1f4;
    if (_0x593ad6) {
        $(_0x1028('0x5a'))[_0x1028('0x2d')](_0x1028('0x2e'));
        $(_0x1028('0x5b'))[_0x1028('0x2d')](_0x1028('0x5c'));
        $(_0x1028('0x5d'))[_0x1028('0x34')]({
            'left': '+=25%',
            'top': _0x1028('0x5e')
        }, _0x2e96c7, _0x1028('0x36'), function () {
            $('#ShowLogin\x20.searchPlayer\x20img')['animate']({
                'left': '+=25%',
                'top': _0x1028('0x5f')
            }, _0x2e96c7, _0x1028('0x36'), function () {
                $('#ShowLogin\x20.searchPlayer\x20img')[_0x1028('0x34')]({
                    'left': '+=45%',
                    'top': _0x1028('0x60')
                }, _0x2e96c7, _0x1028('0x36'), function () {
                    $(_0x1028('0x5d'))[_0x1028('0x34')]({
                        'left': _0x1028('0x61'),
                        'top': _0x1028('0x60')
                    }, _0x2e96c7, _0x1028('0x36'), function () {
                        $('#ShowLogin\x20.searchPlayer\x20img')[_0x1028('0x34')]({
                            'left': '-=25%',
                            'top': _0x1028('0x60')
                        }, _0x2e96c7, _0x1028('0x36'), function () {
                            $(_0x1028('0x5d'))[_0x1028('0x34')]({
                                'left': _0x1028('0x62'),
                                'top': _0x1028('0x39')
                            }, _0x2e96c7, _0x1028('0x36'), function () {
                                $(_0x1028('0x5d'))[_0x1028('0x34')]({
                                    'left': '0',
                                    'top': '0'
                                }, _0x2e96c7, _0x1028('0x36'), function () {
                                    _0x323183();
                                });
                            });
                        });
                    });
                });
            });
        });
    } else {
        $(_0x1028('0x5a'))[_0x1028('0x4d')](_0x1028('0x2e'));
        $(_0x1028('0x5b'))[_0x1028('0x4d')](_0x1028('0x5c'));
    }
}
var _0x2614d4 = !![];

function _0x4076fc() {
    if (_0x2614d4) {
        $(_0x1028('0x63'))[_0x1028('0x24')](_0x1028('0x64'), _0x1028('0x65'));
        $(_0x1028('0x66'))[_0x1028('0x24')](_0x1028('0x67'), _0x1028('0x65'));
        setTimeout(function () {
            $(_0x1028('0x63'))[_0x1028('0x24')]('color', _0x1028('0x68'));
            $(_0x1028('0x66'))[_0x1028('0x24')](_0x1028('0x67'), _0x1028('0x68'));
        }, 0x1f4);
        setTimeout(function () {
            $(_0x1028('0x63'))[_0x1028('0x24')](_0x1028('0x64'), _0x1028('0x69'));
            $(_0x1028('0x66'))[_0x1028('0x24')](_0x1028('0x67'), _0x1028('0x69'));
        }, 0x3e8);
        setTimeout(function () {
            _0x4076fc();
        }, 0x5dc);
    } else {
        $(_0x1028('0x63'))['css'](_0x1028('0x64'), '#717171');
        $(_0x1028('0x66'))[_0x1028('0x24')](_0x1028('0x67'), _0x1028('0x68'));
    }
}

function _0x194f4c() {
    $(_0x1028('0x6a'))[_0x1028('0x6b')](function () {
        var _0x12d2bd = $(this);
        if ($(window)['width']() > 0x2ed) {
            if (_0x12d2bd['hasClass'](_0x1028('0x6c'))) {
                _0x12d2bd[_0x1028('0x6d')](_0x1028('0x6e'));
            }
        } else {
            if (!_0x12d2bd[_0x1028('0x6f')](_0x1028('0x6c'))) {
                _0x12d2bd[_0x1028('0x6d')]({
                    'infinite': !![],
                    'speed': 0x12c,
                    'slidesToShow': 0x1,
                    'slidesToScroll': 0x1,
                    'adaptiveHeight': !![],
                    'prevArrow': _0x12d2bd['parent']()[_0x1028('0x70')]('.left_pointer'),
                    'nextArrow': _0x12d2bd['parent']()[_0x1028('0x70')](_0x1028('0x71')),
                    'mobileFirst': !![]
                });
            }
        }
    });
}

function _0xb1d774() {
    setTimeout(function () {
        $('.playnowbar')[_0x1028('0x24')]({
            'display': 'block',
            'bottom': _0x1028('0x72')
        });
        $(_0x1028('0x73'))[_0x1028('0x34')]({
            'bottom': '0'
        }, 0x1f4, function () {
            $(_0x1028('0x74'))['css']({
                'display': _0x1028('0x75'),
                'bottom': '-60px'
            });
            $(_0x1028('0x74'))[_0x1028('0x34')]({
                'bottom': '0'
            }, 0x1f4, function () {
                function _0x5be925() {
                    $('.pointer')[_0x1028('0x2d')](_0x1028('0x76'));
                    setTimeout(function () {
                        $('.pointer')[_0x1028('0x4d')](_0x1028('0x76'));
                        $(_0x1028('0x77'))['addClass'](_0x1028('0x78'));
                    }, 0x320);
                    setTimeout(function () {
                        $(_0x1028('0x77'))['removeClass'](_0x1028('0x78'));
                    }, 0xbb8);
                    setTimeout(function () {
                        _0x5be925();
                    }, 0x1388);
                }
                _0x5be925();
            });
        });
    }, 0x3e8);
}
var _0x5803aa;

function _0x3c6ed3() {
    _0x5803aa = new YT[(_0x1028('0x79'))](_0x1028('0x7a'), {
        'events': {
            'onStateChange': _0x15b7c8
        }
    });
}
var _0x369b62 = ![];
var _0x55fe22 = ![];

function _0x15b7c8(_0x493780) {
    if (_0x493780['data'] == YT[_0x1028('0x7b')][_0x1028('0x7c')] && !_0x55fe22) {
        _0x55fe22 = !![];
    } else {
        _0x55fe22 = ![];
    }
}
$['fn'][_0x1028('0x7d')] = function (_0x2f5218, _0x35a1d3) {
    var _0x54f412 = $(this);
    if (_0x54f412[_0x1028('0x6f')](_0x1028('0x7e'))) {
        setTimeout(function () {
            _0x54f412[_0x1028('0x7d')](_0x2f5218, _0x35a1d3);
        }, 0x96);
        return;
    }
    _0x54f412['addClass'](_0x1028('0x7f') + _0x2f5218);
    _0x54f412[_0x1028('0x80')](_0x1028('0x81'), function () {
        if (_0x54f412[_0x1028('0x6f')](_0x2f5218)) {
            _0x54f412[_0x1028('0x4d')](_0x2f5218);
        }
        if (_0x54f412['hasClass'](_0x1028('0x7e'))) {
            _0x54f412[_0x1028('0x4d')](_0x1028('0x7e'));
        }
        if (typeof _0x35a1d3 === _0x1028('0x59')) {
            return _0x35a1d3(_0x54f412);
        }
    });
};
jQuery['fn'][_0x1028('0x82')] = function () {
    var _0x339dcd = this;
    _0x339dcd[_0x1028('0x24')](_0x1028('0x83'), 'absolute');

    function _0x39cae9(_0x339dcd) {
        _0x339dcd[_0x1028('0x24')](_0x1028('0x84'), ($(window)[_0x1028('0x51')]() - _0x339dcd[_0x1028('0x85')]()) / 0x2 + $(window)[_0x1028('0x86')]() + 'px');
        _0x339dcd[_0x1028('0x24')](_0x1028('0x56'), ($(window)[_0x1028('0x52')]() - _0x339dcd[_0x1028('0x87')]()) / 0x2 + $(window)[_0x1028('0x88')]() + 'px');
    }
    $(window)['on'](_0x1028('0x89'), function (_0x29c530) {
        _0x39cae9(_0x339dcd);
    });
    $(window)['resize'](function () {
        _0x39cae9(_0x339dcd);
    });
    _0x339dcd[_0x1028('0x8a')](function () {
        _0x39cae9(_0x339dcd);
    });
    _0x39cae9(_0x339dcd);
    return _0x339dcd;
};

function _0x4f244d() {
    var _0x5ca36b = 0x0;
    var _0x3ea0e7 = '';
    var _0xd46f30 = ![];
    $(_0x1028('0x8b'))[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x1f6e6b) {
        _0x1f6e6b[_0x1028('0x8d')]();
        if (_0xd46f30) {
            return;
        }
        _0xd46f30 = !![];
        if (!_0x23a001) {
            alert($('.btnCreateComment')[_0x1028('0x3b')]('nologintxt'));
            _0xd46f30 = ![];
            return ![];
        }
        $(_0x1028('0x8e'))[_0x1028('0x3b')](_0x1028('0x3c'), _0xf75b68);
        $('.sAvatar\x20span')['html']('#' + _0x199192);
        $('.bbcomments')[_0x1028('0x86')](0x0)[_0x1028('0x24')](_0x1028('0x8f'), _0x1028('0x90'));
        $('.bbaddcomment')[_0x1028('0x91')](function () {});
        $(_0x1028('0x8b'))[_0x1028('0x4a')]('slow', 0x0, function () {
            _0xd46f30 = ![];
        });
        var _0x4d4ac7 = ![];
        $(_0x1028('0x92'))[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x1f6e6b) {
            _0x1f6e6b[_0x1028('0x8d')]();
            if (_0x4d4ac7) {
                return;
            }
            _0x4d4ac7 = !![];
            var _0x4922a4 = $(_0x1028('0x93'))['val']();
            if (_0x4922a4 != '') {
                _0x3ea0e7 = _0x4922a4;
                _0x278c62();
                $(_0x1028('0x93'))[_0x1028('0x94')]('');
                $('.closeComment')[_0x1028('0x95')](_0x1028('0x8c'));
            } else {
                alert($(_0x1028('0x92'))[_0x1028('0x3b')](_0x1028('0x96')));
            }
            _0x4d4ac7 = ![];
        });
    });
    var _0x27a6a2 = 0x5;
    var _0x20a459 = [[_0x1028('0x97'), _0x1028('0x98')], [_0x1028('0x99'), _0x1028('0x98')], [_0x1028('0x9a'), _0x1028('0x98')], [_0x1028('0x9b'), _0x1028('0x98')], [_0x1028('0x9c'), _0x1028('0x98')], [_0x1028('0x9d'), _0x1028('0x98')], [_0x1028('0x9e'), _0x1028('0x98')], [_0x1028('0x9f'), _0x1028('0x98')], ['GoJuiced', 'https://i.imgur.com/kIL5IpR.png'], ['xPhilipp637x', _0x1028('0x98')], [_0x1028('0xa0'), _0x1028('0x98')], [_0x1028('0xa1'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xa2'), _0x1028('0x98')], ['glmate', _0x1028('0x98')], [_0x1028('0xa3'), _0x1028('0x98')], [_0x1028('0xa4'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xa5'), _0x1028('0x98')], [_0x1028('0xa6'), _0x1028('0x98')], ['BallerManSam', _0x1028('0x98')], ['Croy_', _0x1028('0x98')], ['GernaderJake', _0x1028('0x98')], [_0x1028('0xa7'), _0x1028('0x98')], [_0x1028('0xa8'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xa9'), _0x1028('0x98')], [_0x1028('0xaa'), _0x1028('0x98')], [_0x1028('0xab'), _0x1028('0x98')], [_0x1028('0xac'), _0x1028('0x98')], ['harryrrah', _0x1028('0x98')], [_0x1028('0xad'), _0x1028('0x98')], [_0x1028('0xae'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xaf'), _0x1028('0x98')], ['xoHypetv', _0x1028('0x98')], ['YolkedPenguin', _0x1028('0x98')], ['watermelon02', _0x1028('0x98')], ['SuperLennyy', _0x1028('0x98')], [_0x1028('0xb0'), _0x1028('0x98')], ['FAZE_Ciko', _0x1028('0x98')], [_0x1028('0xb1'), _0x1028('0x98')], [_0x1028('0xb2'), _0x1028('0x98')], [_0x1028('0xb3'), _0x1028('0x98')], [_0x1028('0xb4'), _0x1028('0x98')], [_0x1028('0xb5'), _0x1028('0x98')], [_0x1028('0xb6'), _0x1028('0x98')], ['twitch_aceqtcs', _0x1028('0x98')], [_0x1028('0xb7'), _0x1028('0x98')], [_0x1028('0xb8'), _0x1028('0x98')], ['YABOITM', _0x1028('0x98')], [_0x1028('0xb9'), _0x1028('0x98')], [_0x1028('0xba'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xbb'), _0x1028('0x98')], [_0x1028('0xbc'), _0x1028('0x98')], [_0x1028('0xbd'), _0x1028('0x98')], [_0x1028('0xbe'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xbf'), _0x1028('0x98')], [_0x1028('0xc0'), _0x1028('0x98')], [_0x1028('0xc1'), _0x1028('0x98')], [_0x1028('0xc2'), _0x1028('0x98')], [_0x1028('0xc3'), _0x1028('0x98')], [_0x1028('0xc4'), _0x1028('0x98')], [_0x1028('0xc5'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xc6'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xc7'), _0x1028('0x98')], [_0x1028('0xc8'), _0x1028('0x98')], [_0x1028('0xc9'), _0x1028('0x98')], [_0x1028('0xca'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xcb'), _0x1028('0x98')], [_0x1028('0xcc'), _0x1028('0x98')], [_0x1028('0xcd'), _0x1028('0x98')], [_0x1028('0xce'), _0x1028('0x98')], [_0x1028('0xcf'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xd0'), _0x1028('0x98')], ['McMuffin047', _0x1028('0x98')], [_0x1028('0xd1'), 'https://i.imgur.com/kIL5IpR.png'], [_0x1028('0xd2'), _0x1028('0x98')], [_0x1028('0xd3'), _0x1028('0x98')], [_0x1028('0xd4'), _0x1028('0x98')], [_0x1028('0xd5'), _0x1028('0x98')], ['Laggy\x20Land', _0x1028('0x98')], [_0x1028('0xd6'), _0x1028('0x98')]];
    var _0xeb109f = [_0x1028('0xd7'), _0x1028('0xd8'), _0x1028('0xd9'), _0x1028('0xda'), _0x1028('0xdb'), _0x1028('0xdc'), _0x1028('0xdd'), _0x1028('0xde'), 'I\x27ll\x20get\x203\x20or\x206\x20months..\x20{Nah|nope}\x20I\x27ll\x20get\x20both\x20instead\x20xD', 'New\x20options\x20will\x20be\x20available\x20soon.\x20Guess\x20who\x20will\x20be\x20the\x20first\x20to\x20get\x20his\x20hands\x20on\x20them\x20:))', _0x1028('0xdf'), _0x1028('0xe0'), _0x1028('0xe1'), 'ayy\x20It\x20Worked\x09', _0x1028('0xe2'), _0x1028('0xe3'), _0x1028('0xe4'), _0x1028('0xe5'), _0x1028('0xe6'), _0x1028('0xe7'), _0x1028('0xe8'), 'Worked\x20perfectly!\x20Thanks!\x09', _0x1028('0xe9'), _0x1028('0xea'), _0x1028('0xeb'), 'thankyou...\x09', _0x1028('0xec'), _0x1028('0xed'), _0x1028('0xee'), _0x1028('0xef'), 'I\x20dont\x20wanna\x20flex\x20but\x20for\x20me\x20it\x20downloaded\x20faster\x09', _0x1028('0xf0'), _0x1028('0xf1'), _0x1028('0xf2'), _0x1028('0xf3'), _0x1028('0xf4'), _0x1028('0xf5'), _0x1028('0xf6'), _0x1028('0xf7'), _0x1028('0xf8'), _0x1028('0xf9'), _0x1028('0xfa'), _0x1028('0xfb'), 'thanks\x20it\x20worked\x20<3\x09', _0x1028('0xfc'), _0x1028('0xfd'), _0x1028('0xfe'), _0x1028('0xff'), 'damn\x20ur\x20internet\x20is\x20freakin\x20fast\x20bro\x20my\x20internet\x20speed\x20is\x20like\x20only\x20100kb\x20per\x20sec.and\x20i\x20have\x20to\x20wait\x20hours\x20to\x20download\x20dis\x20file\x20man\x09', _0x1028('0x100'), 'Worked\x20for\x20me,\x20thanks\x20:)\x09\x09', 'Someone\x20make\x20me\x20one\x20seathst@gmail.com\x09', _0x1028('0x101'), _0x1028('0x102'), _0x1028('0x103'), [0x2, [_0x1028('0x104'), _0x1028('0x105'), _0x1028('0x106')]], [0x2, [_0x1028('0x107'), _0x1028('0x108'), _0x1028('0x109')]], [0x2, [_0x1028('0x10a'), '[USER_1]@[OP_USERNAME]\x20takes\x20time\x20sometimes,\x20yesterday\x20I\x20won\x20on\x20first\x20try\x20but\x20today\x20took\x20few\x20tries...', '[OP]@[USER_1_USERNAME]\x20LOL\x20{makes\x20sense|ok|thank\x20you\x20for\x20remenber\x20me|\x20\x27funny\x27}']], [0x2, ['[OP]Did\x20this\x20on\x20a\x20wrong\x20username\x20...\x20someone\x20got\x20free\x20apple\x20music\x20premium\x20instead\x20of\x20me.\x20Can\x20I\x20do\x20it\x20again\x20?', _0x1028('0x10b'), _0x1028('0x10c')]], [0x2, [_0x1028('0x10d'), _0x1028('0x10e')]], [0x2, [_0x1028('0x10f'), _0x1028('0x110'), '[OP]@[USER_1_USERNAME]\x20because\x20I´ve\x20spent\x20a\x20lotta\x20money\x20on\x20this\x20and\x20now\x20people\x20are\x20getting\x20shit\x20for\x20free?\x20wtf', _0x1028('0x111')]], [0x2, [_0x1028('0x112'), _0x1028('0x113')]]];
    var _0x2049fe = [_0x1028('0x114'), _0x1028('0x115'), _0x1028('0x116')];
    var _0x7fab67 = _0x1028('0x117');
    var _0x1dd405 = localStorage[_0x1028('0x118')](_0x1028('0x119'));
    _0x1dd405 = _0x1dd405 ? JSON[_0x1028('0x11a')](_0x1dd405) : [];
    var _0xca426c = localStorage[_0x1028('0x118')](_0x1028('0x11b'));
    _0xca426c = _0xca426c ? JSON[_0x1028('0x11a')](_0xca426c) : [];
    var _0x989ae0 = localStorage[_0x1028('0x118')](_0x1028('0x11c'));
    _0x989ae0 = _0x989ae0 ? JSON[_0x1028('0x11a')](_0x989ae0) : [];
    var _0x4fca7a = localStorage[_0x1028('0x118')]('CPlayersForCommentsToUse');
    _0x4fca7a = _0x4fca7a ? JSON[_0x1028('0x11a')](_0x4fca7a) : [];
    var _0x296f1d = localStorage[_0x1028('0x118')](_0x1028('0x11d'));
    _0x296f1d = _0x296f1d ? JSON[_0x1028('0x11a')](_0x296f1d) : [];

    function _0x4b55ef(_0x4cdf87) {
        switch (typeof _0x4cdf87) {
            case _0x1028('0x11e'):
                break;
            case _0x1028('0x11f'):
                _0x4cdf87 = +new Date(_0x4cdf87);
                break;
            case _0x1028('0x120'):
                if (_0x4cdf87[_0x1028('0x121')] === Date) _0x4cdf87 = _0x4cdf87[_0x1028('0x122')]();
                break;
            default:
                _0x4cdf87 = +new Date();
        }
        var _0x418e81 = [[0x3c, 'seconds', 0x1], [0x78, _0x1028('0x123'), _0x1028('0x124')], [0xe10, _0x1028('0x125'), 0x3c], [0x1c20, '1\x20hour\x20ago', _0x1028('0x126')], [0x15180, _0x1028('0x127'), 0xe10], [0x2a300, _0x1028('0x128'), _0x1028('0x129')], [0x93a80, 'days', 0x15180], [0x127500, _0x1028('0x12a'), _0x1028('0x12b')], [0x24ea00, _0x1028('0x12c'), 0x93a80], [0x49d400, _0x1028('0x12d'), 'Next\x20month'], [0x1baf800, _0x1028('0x12e'), 0x24ea00], [0x375f000, _0x1028('0x12f'), _0x1028('0x130')], [0xad08e000, _0x1028('0x131'), 0x1baf800], [0x15a11c000, _0x1028('0x132'), _0x1028('0x133')], [0xd84b18000, 'centuries', 0xad08e000]];
        var _0x4a3313 = (+new Date() - _0x4cdf87) / 0x3e8,
            _0x5ed5f4 = _0x1028('0x134'),
            _0x1034f2 = 0x1;
        if (_0x4a3313 == 0x0) {
            return _0x1028('0x135');
        }
        if (_0x4a3313 < 0x0) {
            _0x4a3313 = Math[_0x1028('0x136')](_0x4a3313);
            _0x5ed5f4 = 'from\x20now';
            _0x1034f2 = 0x2;
        }
        var _0x3f6fad = 0x0,
            _0x5a788b;
        while (_0x5a788b = _0x418e81[_0x3f6fad++])
            if (_0x4a3313 < _0x5a788b[0x0]) {
                if (typeof _0x5a788b[0x2] == _0x1028('0x11f')) return _0x5a788b[_0x1034f2];
                else return Math[_0x1028('0x20')](_0x4a3313 / _0x5a788b[0x2]) + '\x20' + _0x5a788b[0x1] + '\x20' + _0x5ed5f4;
            } return _0x4cdf87;
    }

    function _0x488626(_0x12a662) {
        var _0x312f42, _0x2fa1d9, _0x32a77f;
        var _0x1509a6 = new RegExp(/{([^{}]+?)}/);
        while ((_0x312f42 = _0x1509a6[_0x1028('0x137')](_0x12a662)) !== null) {
            _0x2fa1d9 = _0x312f42[0x1][_0x1028('0x9')]('|');
            _0x32a77f = Math[_0x1028('0x20')](Math[_0x1028('0x21')]() * _0x2fa1d9['length']);
            _0x12a662 = _0x12a662[_0x1028('0x8')](_0x312f42[0x0], _0x2fa1d9[_0x32a77f]);
        }
        return _0x12a662;
    }

    function _0x2b3ddd() {
        if ($('.bbcomments-area\x20.bbcomment')[_0x1028('0xb')] >= _0x27a6a2) {
            $(_0x1028('0x138'))[_0x1028('0x55')]()[_0x1028('0x139')](function () {
                $(this)[_0x1028('0x13a')]()[_0x1028('0x40')]();
            });
        }
    }

    function _0x281c80() {
        var _0x5bbbe8 = _0x2049fe[_0x1028('0xb')];
        if (_0x5bbbe8 != 0x0) {
            _0x5bbbe8 = _0x5bbbe8 - 0x1;
        }
        if (_0xca426c[_0x1028('0xb')] === 0x0) {
            for (var _0x2f73a7 = 0x0; _0x2f73a7 <= _0x5bbbe8; _0x2f73a7++) {
                _0xca426c[_0x1028('0x13b')](_0x2f73a7);
            }
            localStorage[_0x1028('0x13c')](_0x1028('0x11b'), JSON[_0x1028('0x13d')](_0xca426c['shuffle']()));
        }
    }

    function _0x203e59() {
        var _0x42cfa9 = _0x20a459[_0x1028('0xb')];
        if (_0x42cfa9 != 0x0) {
            _0x42cfa9 = _0x42cfa9 - 0x1;
        }
        if (_0x4fca7a[_0x1028('0xb')] === 0x0) {
            for (var _0xbf0bd0 = 0x0; _0xbf0bd0 <= _0x42cfa9; _0xbf0bd0++) {
                _0x4fca7a[_0x1028('0x13b')](_0xbf0bd0);
            }
            localStorage[_0x1028('0x13c')](_0x1028('0x13e'), JSON[_0x1028('0x13d')](_0x4fca7a['shuffle']()));
        }
    }

    function _0x24cc52() {
        var _0x401452 = _0xeb109f[_0x1028('0xb')];
        if (_0x401452 != 0x0) {
            _0x401452 = _0x401452 - 0x1;
        }
        if (_0x1dd405[_0x1028('0xb')] === 0x0) {
            for (var _0x2fac3a = 0x0; _0x2fac3a <= _0x401452; _0x2fac3a++) {
                _0x1dd405[_0x1028('0x13b')](_0x2fac3a);
            }
            localStorage[_0x1028('0x13c')](_0x1028('0x119'), JSON[_0x1028('0x13d')](_0x1dd405[_0x1028('0x23')]()));
        }
    }

    function _0x2d2983() {
        var _0x234304 = _0x20a459[_0x1028('0xb')];
        if (_0x234304 != 0x0) {
            _0x234304 = _0x234304 - 0x1;
        }
        if (_0x296f1d[_0x1028('0xb')] === 0x0) {
            for (var _0x1d5e14 = 0x0; _0x1d5e14 <= _0x234304; _0x1d5e14++) {
                _0x296f1d[_0x1028('0x13b')](_0x1d5e14);
            }
            localStorage[_0x1028('0x13c')](_0x1028('0x11d'), JSON[_0x1028('0x13d')](_0x296f1d[_0x1028('0x23')]()));
        }
    }

    function _0x244d4c() {
        _0x203e59();
    }

    function _0x218b48() {
        _0x2d2983();
    }

    function _0x5a7ae2() {
        _0x24cc52();
    }

    function _0x10c715() {
        _0x281c80();
    }

    function _0x5583e1() {
        if (_0x4fca7a[_0x1028('0xb')] === 0x0) {
            console[_0x1028('0x13')](_0x1028('0x13f'));
            _0x244d4c();
        }
        var _0x1dd018 = _0x4fca7a[0x0];
        _0x4fca7a[_0x1028('0x140')]();
        localStorage[_0x1028('0x13c')](_0x1028('0x13e'), JSON[_0x1028('0x13d')](_0x4fca7a));
        return _0x20a459[_0x1dd018];
    }

    function _0x3d4c13() {
        if (_0x296f1d[_0x1028('0xb')] === 0x0) {
            console['log'](_0x1028('0x141'));
            _0x218b48();
        }
        var _0x35b7c9 = _0x296f1d[0x0];
        _0x296f1d[_0x1028('0x140')]();
        localStorage[_0x1028('0x13c')](_0x1028('0x11d'), JSON[_0x1028('0x13d')](_0x296f1d));
        return _0x20a459[_0x35b7c9];
    }

    function _0x544552() {
        if (_0x1dd405[_0x1028('0xb')] === 0x0) {
            console[_0x1028('0x13')](_0x1028('0x142'));
            _0x5a7ae2();
        }
        var _0x4efd0f = _0x1dd405[0x0];
        _0x1dd405[_0x1028('0x140')]();
        localStorage['setItem'](_0x1028('0x119'), JSON[_0x1028('0x13d')](_0x1dd405));
        return _0xeb109f[_0x4efd0f];
    }

    function _0x242aa0() {
        if (_0xca426c[_0x1028('0xb')] === 0x0) {
            console[_0x1028('0x13')]('Reset\x20GetCommentsToReply');
            _0x10c715();
        }
        var _0x4c5ff4 = _0xca426c[0x0];
        _0xca426c[_0x1028('0x140')]();
        localStorage[_0x1028('0x13c')](_0x1028('0x11b'), JSON[_0x1028('0x13d')](_0xca426c));
        return _0x2049fe[_0x4c5ff4];
    }

    function _0x278c62() {
        var _0x40ef88 = _0x7fab67;
        _0x40ef88 = _0x40ef88[_0x1028('0x8')](_0x1028('0x143'), _0xf75b68);
        _0x40ef88 = _0x40ef88[_0x1028('0x8')](_0x1028('0x144'), _0x199192);
        _0x40ef88 = _0x40ef88[_0x1028('0x8')](_0x1028('0x145'), _0x3ea0e7);
        _0x40ef88 = _0x40ef88[_0x1028('0x8')](_0x1028('0x146'), new Date()['getTime']());
        _0x40ef88 = _0x40ef88[_0x1028('0x8')]('[TIME_POST]', 'Posted\x20<t>now</t>');
        $(_0x1028('0x147'))['scrollTop'](0x0);
        $(_0x1028('0x147'))[_0x1028('0x148')](_0x40ef88)[_0x1028('0x70')](_0x1028('0x149'))[_0x1028('0x14a')]()['hide']()[_0x1028('0x14b')]();
        _0x2b3ddd();
        _0x5ca36b = 0x1;
    }

    function _0xdb9305() {
        var _0x52115b = _0x544552();
        if (_0x52115b instanceof Array) {
            var _0x3b4949 = [[]];
            var _0x544e65 = _0x52115b[0x0];
            var _0x36b566 = [];
            for (var _0x29b9ec = 0x0; _0x29b9ec < _0x544e65; _0x29b9ec++) {
                _0x36b566['push'](_0x5583e1());
            }
            for (var _0x29b9ec = 0x0; _0x29b9ec < _0x52115b[0x1]['length']; _0x29b9ec++) {
                var _0x3356ce = _0x52115b[0x1][_0x29b9ec];
                _0x3b4949[_0x29b9ec] = [];
                if (_0x3356ce[_0x1028('0xc')](_0x1028('0x14c')) !== -0x1) {
                    _0x3b4949[_0x29b9ec][_0x1028('0x14d')] = _0x1028('0x14e');
                    _0x3b4949[_0x29b9ec][_0x1028('0x14f')] = _0x36b566[0x0];
                }
                for (var _0x16f5d7 = 0x0; _0x16f5d7 < _0x36b566[_0x1028('0xb')] - 0x1; _0x16f5d7++) {
                    if (_0x3356ce['indexOf']('[USER_' + (_0x16f5d7 + 0x1) + ']') !== -0x1) {
                        _0x3b4949[_0x29b9ec][_0x1028('0x14d')] = _0x1028('0x150');
                        _0x3b4949[_0x29b9ec][_0x1028('0x14f')] = _0x36b566[_0x16f5d7 + 0x1];
                        _0x3356ce = _0x3356ce[_0x1028('0x8')](_0x1028('0x151') + (_0x16f5d7 + 0x1) + ']', '');
                    }
                    if (_0x3356ce[_0x1028('0xc')](_0x1028('0x151') + (_0x16f5d7 + 0x1) + _0x1028('0x152')) !== -0x1) {
                        _0x3356ce = _0x3356ce[_0x1028('0x8')](_0x1028('0x151') + (_0x16f5d7 + 0x1) + _0x1028('0x152'), _0x36b566[_0x16f5d7 + 0x1][0x0]);
                    }
                    if (_0x3356ce[_0x1028('0xc')](_0x1028('0x153')) !== -0x1) {
                        _0x3356ce = _0x3356ce['replace']('[OP_USERNAME]', _0x36b566[0x0][0x0]);
                    }
                }
                _0x3356ce = _0x3356ce['replace'](_0x1028('0x14c'), '');
                _0x3356ce = _0x3356ce[_0x1028('0x8')](_0x1028('0x153'), _0x36b566[0x0]);
                _0x3b4949[_0x29b9ec]['comment'] = _0x488626(_0x3356ce);
            }
        } else {
            var _0x3b4949 = [];
            _0x3b4949[_0x1028('0x14d')] = _0x1028('0x154');
            _0x3b4949['user'] = _0x5583e1();
            _0x3b4949[_0x1028('0x155')] = _0x488626(_0x52115b);
        }
        return _0x3b4949;
    }

    function _0x31eb25(_0x5ce790) {
        var _0x3e782c = _0x242aa0();
        if (_0x3e782c[_0x1028('0xc')]('[OP_USER]') !== -0x1) {
            _0x3e782c = _0x3e782c['replace'](_0x1028('0x156'), _0x199192);
        }
        if (_0x3e782c[_0x1028('0xc')](_0x1028('0x157')) !== -0x1) {
            _0x3e782c = _0x3e782c[_0x1028('0x8')](_0x1028('0x157'), _0x5ce790);
        }
        _0x3e782c = _0x488626(_0x3e782c);
        var _0x5c2201 = [];
        _0x5c2201[_0x1028('0x14d')] = _0x1028('0x158');
        _0x5c2201[_0x1028('0x14f')] = _0x5583e1();
        _0x5c2201[_0x1028('0x155')] = _0x3e782c;
        return _0x5c2201;
    }

    function _0x2663cd(_0x151bea) {
        if (_0x151bea[_0x1028('0xb')] > 0x0) {
            for (var _0x8a6c35 = 0x0; _0x8a6c35 <= _0x151bea[_0x1028('0xb')]; _0x8a6c35++) {
                if (_0x151bea[_0x8a6c35]) _0x989ae0[_0x1028('0x13b')](_0x151bea[_0x8a6c35]);
            }
        } else {
            _0x989ae0['push'](_0x151bea);
        }
        localStorage[_0x1028('0x13c')](_0x1028('0x11c'), JSON['stringify'](_0x989ae0));
    }

    function _0x5badef() {
        var _0x3d97eb = _0x989ae0[0x0];
        _0x989ae0['shift']();
        localStorage[_0x1028('0x13c')](_0x1028('0x11c'), JSON[_0x1028('0x13d')](_0x989ae0));
        return _0x3d97eb;
    }

    function _0x56c58e() {
        if (_0x989ae0[_0x1028('0xb')] > 0x0) {
            return !![];
        } else {
            return ![];
        }
    }

    function _0x19f155() {
        var _0x38c493 = _0x63c02b(0x3, 0x4);
        var _0x325465 = _0x63c02b(0x2, 0x8);
        for (var _0x41def1 = 0x0; _0x41def1 <= _0x38c493; _0x41def1++) {
            if (_0x41def1 == 0x0) {
                var _0x34bf04 = new Date(new Date()[_0x1028('0x122')]() - 0x3e8 * 0x3c * _0x325465)[_0x1028('0x122')]();
            } else {
                var _0x19b292 = parseInt(_0x325465 / (_0x41def1 + 0x1));
                var _0x34bf04 = new Date(new Date()[_0x1028('0x122')]() - 0x3e8 * 0x3c * _0x19b292)['getTime']();
            }
            if (!_0x56c58e()) {
                _0x2663cd(_0xdb9305());
            }
            var _0x279346 = _0x5badef();
            if (_0x279346[_0x1028('0x14f')]) {
                var _0x3b810e = _0x7fab67;
                _0x3b810e = _0x3b810e[_0x1028('0x8')](_0x1028('0x143'), _0x279346[_0x1028('0x14f')][0x1]);
                _0x3b810e = _0x3b810e[_0x1028('0x8')](_0x1028('0x144'), _0x279346[_0x1028('0x14f')][0x0]);
                _0x3b810e = _0x3b810e[_0x1028('0x8')](_0x1028('0x145'), _0x279346[_0x1028('0x155')]);
                _0x3b810e = _0x3b810e[_0x1028('0x8')](_0x1028('0x146'), _0x34bf04);
                _0x3b810e = _0x3b810e[_0x1028('0x8')](_0x1028('0x159'), _0x1028('0x15a'));
                $(_0x1028('0x147'))[_0x1028('0x148')](_0x3b810e);
            }
        }
        _0x2abd07 = setInterval(function () {
            if ($(_0x1028('0x15b'))[_0x1028('0xb')] > 0x0) {
                $(_0x1028('0x15b'))[_0x1028('0x6b')](function () {
                    var _0x29b3ea = parseInt($(this)[_0x1028('0x3b')](_0x1028('0x15c')));
                    $(this)[_0x1028('0x40')](_0x4b55ef(new Date(_0x29b3ea)));
                });
            }
        }, 0x3e8);
    }
    var _0x30d350 = _0x63c02b(0x7d0, 0x1388);
    var _0xa217b1 = 0x0;

    function _0x300144() {
        clearTimeout(_0x1edf27);
        _0x1edf27 = setTimeout(function () {
            _0x30d350 = _0x63c02b(0x2710, 0x61a8);
            if (_0x56c58e()) {
                var _0x415ed4 = _0x5badef();
                if (_0x415ed4['user']) {
                    var _0x5933ca = _0x7fab67;
                    _0x5933ca = _0x5933ca[_0x1028('0x8')](_0x1028('0x143'), _0x415ed4[_0x1028('0x14f')][0x1]);
                    _0x5933ca = _0x5933ca[_0x1028('0x8')](_0x1028('0x144'), _0x415ed4[_0x1028('0x14f')][0x0]);
                    _0x5933ca = _0x5933ca[_0x1028('0x8')](_0x1028('0x145'), _0x415ed4[_0x1028('0x155')]);
                    _0x5933ca = _0x5933ca[_0x1028('0x8')](_0x1028('0x146'), new Date()['getTime']());
                    _0x5933ca = _0x5933ca[_0x1028('0x8')](_0x1028('0x159'), _0x1028('0x15d'));
                    $('.bbcomments-area')['scrollTop'](0x0);
                    $('.bbcomments-area')[_0x1028('0x148')](_0x5933ca)['find'](_0x1028('0x149'))[_0x1028('0x14a')]()[_0x1028('0x2f')]()[_0x1028('0x14b')]();
                    _0x2b3ddd();
                    _0xa217b1++;
                }
            } else {
                if (_0x5ca36b) {
                    _0x5ca36b = 0x0;
                    for (var _0x3e0b6d = 0x0; _0x3e0b6d <= _0x63c02b(0x1, 0x3); _0x3e0b6d++) {
                        _0x2663cd(_0x31eb25(_0x3ea0e7));
                    }
                    _0x30d350 = _0x63c02b(0xbb8, 0x1388);
                } else {
                    _0x2663cd(_0xdb9305());
                    _0x30d350 = _0x63c02b(0x1388, 0x2710);
                }
            }
            _0x300144();
        }, _0x30d350);
    }
    var _0x166135 = ![];

    function _0x2d88b0() {
        if (_0x166135) {
            var _0x409477 = _0x63c02b(0x1388, 0x2710);
        } else {
            _0x166135 = !![];
            var _0x409477 = 0xc8;
        }
        var _0x543613 = [0x3, 0x6, 0xc];
        _0x4904f7 = setTimeout(function () {
            var _0x38bd2f = _0x63c02b(0x2, 0x6);
            $(_0x1028('0x15e'))['css'](_0x1028('0x15f'), _0x1028('0x90'));
            for (var _0x153f81 = 0x0; _0x153f81 <= 0x3; _0x153f81++) {
                var _0x761de2 = _0x543613[_0x63c02b(0x0, 0x1)];
                var _0x6185c = _0x3d4c13();
                if (_0x153f81 == 0x0) {
                    var _0xefb216 = new Date(new Date()['getTime']() - 0x3e8 * 0x3c * _0x38bd2f)[_0x1028('0x122')]();
                } else {
                    var _0x20a1bc = parseInt(_0x38bd2f / (_0x153f81 + 0x1));
                    var _0xefb216 = new Date(new Date()['getTime']() - 0x3e8 * 0x3c * _0x20a1bc)[_0x1028('0x122')]();
                }
                var _0xefb216 = _0x4b55ef(new Date(_0xefb216));
                $(_0x1028('0x15e'))['eq'](_0x153f81)[_0x1028('0x4d')](_0x1028('0x160'));
                $(_0x1028('0x15e'))['eq'](_0x153f81)[_0x1028('0x70')](_0x1028('0x161'))[_0x1028('0x40')](_0x1028('0x162') + _0x6185c[0x0]);
                $('.bbbox')['eq'](_0x153f81)[_0x1028('0x70')](_0x1028('0x163'))[_0x1028('0x3b')](_0x1028('0x3c'), _0x6185c[0x1]);
                $(_0x1028('0x15e'))['eq'](_0x153f81)[_0x1028('0x70')](_0x1028('0x164'))[_0x1028('0x40')](_0xefb216);
                $('.bbbox')['eq'](_0x153f81)[_0x1028('0x70')]('.bbvbucks')[_0x1028('0x40')](_0x761de2 + _0x1028('0x165'));
            }
            var _0x3aec90 = 0x32;
            $(_0x1028('0x15e'))['each'](function (_0x2bfdf0) {
                var _0xedfa64 = $(this);
                setTimeout(function () {
                    _0xedfa64['css'](_0x1028('0x15f'), _0x1028('0x166'))['show']()[_0x1028('0x2d')](_0x1028('0x160'));
                }, _0x3aec90);
                _0x3aec90 = _0x3aec90 + 0x64;
                if ($('.bbbox')[_0x1028('0x55')]()['index']() == _0x2bfdf0) {
                    _0x2d88b0();
                }
            });
        }, _0x409477);
    }
    var _0x3a3700 = ![];
    $(_0x1028('0x167'))[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x5f86d1) {
        _0x5f86d1[_0x1028('0x8d')]();
        if (_0x3a3700) {
            return;
        }
        _0x3a3700 = !![];
        $('.bbcomments')['scrollTop'](0x0)['css'](_0x1028('0x8f'), 'auto');
        $(_0x1028('0x168'))['fadeOut'](function () {});
        $(_0x1028('0x8b'))[_0x1028('0x4a')](_0x1028('0x169'), 0x1, function () {
            _0x3a3700 = ![];
        });
    });
    _0x218b48();
    _0x244d4c();
    _0x5a7ae2();
    _0x10c715();
    _0x19f155();
    _0x2d88b0();
    _0x300144();
}
var _0x1edf27;
var _0x2abd07;
var _0x4904f7;

function _0x2844ec() {
    TotalCommentsCreated = 0x0;
    clearTimeout(_0x1edf27);
    clearInterval(_0x2abd07);
    clearInterval(_0x4904f7);
    $('.bbcomments-area')[_0x1028('0x40')]('');
}

function _0x3d5b4d() {
    _0x4f244d();
}
$(document)['ready'](function () {
    var _0x314a7e = _0x1028('0x16a');
    var _0x27534d = Math[_0x1028('0x16b')]($(_0x1028('0x16c'))[_0x1028('0x51')]());
    ion[_0x1028('0x16d')]({
        'sounds': [{
            'name': _0x1028('0x16e')
        }, {
            'name': _0x1028('0x8c')
        }, {
            'name': _0x1028('0x16f')
        }, {
            'name': _0x1028('0x170'),
            'loop': !![]
        }],
        'volume': 0x1,
        'path': _0x1028('0x171'),
        'multiplay': !![],
        'preload': !![]
    });
    _0x194f4c();
    $(window)['on'](_0x1028('0x172'), function () {
        _0x194f4c();
    });
    if (!_0x5d71e7) {
        $(_0x1028('0x173'))[_0x1028('0x2f')]();
    }
    if (_0x4f8e47()[_0x1028('0x174')] == _0x1028('0x175')) {
        $(_0x1028('0x176'))[_0x1028('0x2f')]();
        $(_0x1028('0x177'))[_0x1028('0x91')](function () {
            $(_0x1028('0x178'))[_0x1028('0x4a')]('fast', 0x0, function () {
                $(this)[_0x1028('0x2d')](_0x1028('0x179'))[_0x1028('0x4a')](_0x1028('0x17a'), 0x1, function () {});
            });
        });
        $(_0x1028('0x17b'))[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x17c'));
        return ![];
    }
    _0xb1d774();
    var _0x170a07 = ![];
    $(_0x1028('0x17d'))['click'](function (_0x32332b) {
        _0x32332b[_0x1028('0x8d')]();
        if (_0x170a07) {
            return;
        }
        _0x170a07 = !![];
        ion[_0x1028('0x16d')][_0x1028('0x17e')](_0x1028('0x8c'));
        _0x3d5b4d();
        $(_0x1028('0x17f'))[_0x1028('0x24')](_0x1028('0x180'), _0x1028('0x90'));
        if ($(this)['hasClass']('right')) {
            $(this)['css'](_0x1028('0x83'), 'relative')[_0x1028('0x34')]({
                'top': _0x1028('0x181')
            }, {
                'duration': 0xc8
            })[_0x1028('0x47')]()['done'](function () {
                $(this)['css'](_0x1028('0x83'), _0x1028('0x182'))[_0x1028('0x34')]({
                    'top': _0x1028('0x183')
                }, {
                    'duration': 0xc8,
                    'easing': _0x1028('0x184')
                })[_0x1028('0x47')]()[_0x1028('0x48')](function () {});
            });
        }
        $(_0x1028('0x177'))[_0x1028('0x91')](function () {
            $('.ShowInfoBoard')[_0x1028('0x91')](function () {
                _0x170a07 = ![];
            });
        });
    });
    var _0x4478a0 = ![];
    $(_0x1028('0x185'))[_0x1028('0x8c')](function (_0x3f5433) {
        _0x3f5433[_0x1028('0x8d')]();
        if (_0x4478a0) {
            return;
        }
        _0x4478a0 = !![];
        ion[_0x1028('0x16d')][_0x1028('0x17e')](_0x1028('0x8c'));
        $(_0x1028('0x17f'))['css'](_0x1028('0x180'), _0x1028('0x166'));
        $(this)[_0x1028('0x186')]()[_0x1028('0x38')](function () {
            $(this)[_0x1028('0x186')]()[_0x1028('0x38')](function () {
                _0x2844ec();
                _0x4478a0 = ![];
            });
        });
    });
    var _0x24c545 = ![];
    $(_0x1028('0x77'))[_0x1028('0x8c')](function (_0x5bb130) {
        _0x5bb130[_0x1028('0x8d')]();
        if (_0x24c545) {
            return;
        }
        _0x24c545 = !![];
        ion[_0x1028('0x16d')]['play'](_0x1028('0x8c'));
        ion[_0x1028('0x16d')][_0x1028('0x17e')](_0x1028('0x170'), {
            'volume': 0.3
        });
        $(_0x1028('0x187'))[_0x1028('0x38')](function () {
            $('.playnowbar,.btnPlayNow')['fadeOut']();
        });
        $(_0x1028('0x188'))[_0x1028('0x34')]({
            'scrollTop': 0x0
        }, 0x3e8, function () {})[_0x1028('0x47')]()[_0x1028('0x189')](function () {
            $(_0x1028('0x18a'))[_0x1028('0x2f')]();
            $(_0x1028('0x177'))[_0x1028('0x91')](function () {
                $(_0x1028('0x178'))[_0x1028('0x4a')]('fast', 0x0, function () {
                    $(this)[_0x1028('0x2d')](_0x1028('0x179'))[_0x1028('0x4a')](_0x1028('0x17a'), 0x1, function () {});
                });
            });
            setTimeout(function () {
                $(_0x1028('0x5b'))[_0x1028('0x2b')]()['centerElement']()[_0x1028('0x7d')](_0x1028('0x18b'));
            }, 0x320);
        });
    });
    $(_0x1028('0x18c'))[_0x1028('0x18d')](function () {
        $('#ShowLogin')[_0x1028('0x7d')](_0x1028('0x18e'));
        setTimeout(function () {
            $(_0x1028('0x18f'))[_0x1028('0x24')](_0x1028('0x64'), $(_0x1028('0x18c'))['css'](_0x1028('0x190')));
        }, 0xc8);
    });
    $('.usernameInput')[_0x1028('0x191')](function () {
        $('#ShowLogin')[_0x1028('0x4d')](_0x1028('0x192'));
        $(_0x1028('0x18f'))[_0x1028('0x24')](_0x1028('0x64'), 'rgb(102,\x20178,\x20255)');
    });
    var _0x32911a = ![];
    $(_0x1028('0x193'))[_0x1028('0x8c')](function (_0x1380c6) {
        _0x1380c6[_0x1028('0x8d')]();
        ion['sound'][_0x1028('0x17e')]('click');
        if (_0x32911a) {
            return;
        }
        _0x32911a = !![];
        $(this)[_0x1028('0x7d')]('bounceIn', function () {});
        $(_0x1028('0x194'))[_0x1028('0x40')]('');
        if ($(_0x1028('0x18c'))[_0x1028('0x94')]() == '' || $(_0x1028('0x18c'))['val']()[_0x1028('0xb')] < 0x4) {
            $(_0x1028('0x194'))[_0x1028('0x40')]($(this)[_0x1028('0x3b')](_0x1028('0x96')))['AnimeEffect']('bounceIn');
            _0x32911a = ![];
            return ![];
        }
        $(_0x1028('0x195'))[_0x1028('0x2f')]();
        $(_0x1028('0x196'))[_0x1028('0x40')]('#' + $(_0x1028('0x18c'))[_0x1028('0x94')]());
        $[_0x1028('0x197')]({
            'url': _0x1028('0x198'),
            'type': _0x1028('0x199'),
            'data': {
                'u': $(_0x1028('0x18c'))['val']()
            },
            'beforeSend': function () {
                $(_0x1028('0x19a'))[_0x1028('0x7d')]('fadeOutUp\x20faster', function () {
                    _0x32911a = ![];
                    $(_0x1028('0x19a'))[_0x1028('0x2f')]();
                    $(_0x1028('0x5a'))[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x19b'), function () {
                        setTimeout(function () {
                            $('.SearchIMGaction')[_0x1028('0x91')]();
                            _0x593ad6 = !![];
                            _0x323183();
                            _0x2614d4 = !![];
                            _0x4076fc();
                        }, 0xfa0);
                    });
                });
            }
        })[_0x1028('0x48')](function (_0x5bbabe) {
            console[_0x1028('0x13')](_0x5bbabe);
            var _0x37b7fb = $[_0x1028('0x19c')](_0x5bbabe);
            if (_0x37b7fb[_0x1028('0x19d')]) {
                $(_0x1028('0x194'))[_0x1028('0x40')]($(_0x1028('0x194'))['attr'](_0x1028('0x96')))['hide']();
                _0x593ad6 = ![];
                _0x2614d4 = ![];
                setTimeout(function () {
                    $(_0x1028('0x5a'))['off']()[_0x1028('0x7d')](_0x1028('0x19e'), function () {
                        $(_0x1028('0x5a'))[_0x1028('0x2f')]();
                        $(_0x1028('0x19a'))['off']()[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x19b'), function () {
                            $(_0x1028('0x194'))[_0x1028('0x91')](0x3e8);
                            $('.usernameInput')[_0x1028('0x31')]()[_0x1028('0x80')](_0x1028('0x8c'), function (_0x2a51dc) {
                                $('#ShowLogin\x20.firstPart\x20.error')[_0x1028('0x38')](function () {
                                    $(this)[_0x1028('0x40')]('');
                                });
                            });
                        });
                    });
                }, 0x1f4);
                return ![];
            }
            if (_0x37b7fb[_0x1028('0x19f')]) {
                $('#UserFoundBOX\x20.username')[_0x1028('0x40')]('#' + $('.usernameInput')['val']());
                var _0x30b2b8 = '';
                _0x30b2b8 = _0x30b2b8 + _0x1028('0x1a0') + _0x37b7fb[_0x1028('0x1a1')] + _0x1028('0x1a2');
                if (_0x37b7fb['country_img']) {
                    _0x30b2b8 = _0x30b2b8 + _0x1028('0x1a0') + _0x37b7fb[_0x1028('0x1a3')] + _0x1028('0x1a4');
                }
                $(_0x1028('0x1a5'))['html'](_0x30b2b8);
                var _0x2f5b29;
                var _0x4f6755 = _0x37b7fb[_0x1028('0x1a6')];
                var _0x570638 = '';
                for (_0x2f5b29 = 0x0; _0x2f5b29 < _0x4f6755[_0x1028('0xb')]; ++_0x2f5b29) {
                    _0x570638 = _0x570638 + _0x1028('0x1a7') + _0x4f6755[_0x2f5b29] + _0x1028('0x1a8');
                }
                $(_0x1028('0x1a9'))[_0x1028('0x40')](_0x570638);
                _0x593ad6 = ![];
                _0x2614d4 = ![];
                $(_0x1028('0x5b'))['AnimeEffect'](_0x1028('0x1aa'), function () {
                    $(_0x1028('0x5a'))[_0x1028('0x2f')]();
                    $(_0x1028('0x5b'))[_0x1028('0x2f')]();
                    $(_0x1028('0x1ab'))[_0x1028('0x31')]()[_0x1028('0x2b')]()[_0x1028('0x82')]()[_0x1028('0x7d')](_0x1028('0x1ac'), function () {
                        var _0x9d9c2c = ![];
                        $(_0x1028('0x1ad'))[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x1380c6) {
                            _0x1380c6[_0x1028('0x8d')]();
                            if (_0x9d9c2c) {
                                return;
                            }
                            _0x9d9c2c = !![];
                            ion[_0x1028('0x16d')]['play'](_0x1028('0x8c'));
                            $(_0x1028('0x1ab'))[_0x1028('0x31')]()['AnimeEffect']('flipOutY\x20faster', function () {
                                $('#UserFoundBOX')[_0x1028('0x2f')]();
                                $(_0x1028('0x5b'))[_0x1028('0x31')]()[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x1ac'), function () {});
                                $(_0x1028('0x19a'))[_0x1028('0x31')]()['show']();
                            });
                        });
                        var _0x3b01a1 = ![];
                        $('#UserFoundBOX\x20.actbtns\x20.btnContinue')[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x1380c6) {
                            _0x1380c6[_0x1028('0x8d')]();
                            if (_0x3b01a1) {
                                return;
                            }
                            _0x3b01a1 = !![];
                            ion[_0x1028('0x16d')][_0x1028('0x17e')](_0x1028('0x8c'));
                            $('#UserFoundBOX')[_0x1028('0x31')]()[_0x1028('0x7d')](_0x1028('0x1aa'), function () {
                                $(_0x1028('0x1ab'))[_0x1028('0x2f')]();
                                $(_0x1028('0x1ae'))[_0x1028('0x31')]()[_0x1028('0x2b')]()[_0x1028('0x82')]()[_0x1028('0x7d')](_0x1028('0x1ac'), function () {
                                    var _0x55254b = ![];
                                    $('#ReadyToPlayBOX\x20.btnOK')['off']()[_0x1028('0x8c')](function (_0x1380c6) {
                                        _0x1380c6[_0x1028('0x8d')]();
                                        if (_0x55254b) {
                                            return;
                                        }
                                        _0x55254b = !![];
                                        $(_0x1028('0x1ae'))['off']()[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x1aa'), function () {
                                            $(_0x1028('0x1ae'))[_0x1028('0x2f')]();
                                            _0x15dcb6($('.usernameInput')['val'](), _0x37b7fb[_0x1028('0x1a1')]);
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            } else {
                $('.SearchIMGaction')[_0x1028('0x91')]();
                _0x323183();
                _0x593ad6 = ![];
                _0x2614d4 = ![];
                setTimeout(function () {
                    $(_0x1028('0x5a'))[_0x1028('0x7d')](_0x1028('0x19e'), function () {
                        $('#ShowLogin\x20.SearchingPart')[_0x1028('0x2f')]();
                        $(_0x1028('0x5b'))[_0x1028('0x82')]();
                        $(_0x1028('0x5b'))['off']()[_0x1028('0x7d')](_0x1028('0x1aa'), function () {
                            $(_0x1028('0x5b'))['hide']();
                            $(_0x1028('0x1ae'))[_0x1028('0x31')]()['show']()[_0x1028('0x82')]()['AnimeEffect'](_0x1028('0x1ac'), function () {
                                var _0x2bc686 = ![];
                                $('#ReadyToPlayBOX\x20.btnOK')[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x1380c6) {
                                    _0x1380c6['preventDefault']();
                                    if (_0x2bc686) {
                                        return;
                                    }
                                    _0x2bc686 = !![];
                                    $('#ReadyToPlayBOX')[_0x1028('0x31')]()[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x1aa'), function () {
                                        $(_0x1028('0x1ae'))[_0x1028('0x2f')]();
                                        _0x15dcb6($(_0x1028('0x18c'))['val'](), _0x1028('0x1af'));
                                    });
                                });
                            });
                        });
                    });
                }, 0xbb8);
            }
        })[_0x1028('0x1b0')](function (_0x21efb6, _0x5bef15, _0x5d5a88) {
            setTimeout(function () {
                $(_0x1028('0x194'))['html']($(_0x1028('0x194'))[_0x1028('0x3b')](_0x1028('0x96')))['hide']();
                _0x593ad6 = ![];
                _0x2614d4 = ![];
                setTimeout(function () {
                    $(_0x1028('0x5a'))[_0x1028('0x7d')](_0x1028('0x19e'), function () {
                        $(_0x1028('0x5a'))[_0x1028('0x2f')]();
                        $(_0x1028('0x19a'))[_0x1028('0x2b')]()[_0x1028('0x7d')](_0x1028('0x19b'), function () {
                            $('#ShowLogin\x20.firstPart\x20.error')[_0x1028('0x91')](0x3e8);
                            $(_0x1028('0x18c'))[_0x1028('0x80')]('click', function (_0x1103b9) {
                                $(_0x1028('0x194'))[_0x1028('0x38')](function () {
                                    $(this)[_0x1028('0x40')]('');
                                });
                            });
                        });
                    });
                }, 0x1f4);
            }, 0x7d0);
        });
    });

    function _0x15dcb6(_0x1f19ac, _0x497a5e) {
        _0x23a001 = 0x1;
        if (_0x497a5e == _0x1028('0x1af')) {
            _0x497a5e = _0x1028('0x1b1');
        }
        _0x199192 = _0x1f19ac;
        _0xf75b68 = _0x497a5e;
        _0x349a83 = _0x1579a9();
        $(_0x1028('0x177'))[_0x1028('0x2f')]();
        $('.overLayvbmachine')[_0x1028('0x91')]();
        $(_0x1028('0x1b2'))[_0x1028('0x31')]()['show']()[_0x1028('0x82')]()[_0x1028('0x7d')]('flipInY', function () {});
    }
    var _0x57a93e = [_0x1028('0x1b3'), _0x1028('0x1b4'), _0x1028('0x1b5')];
    $(_0x1028('0x1b6'))[_0x1028('0x40')](_0x1431e9);
    $(_0x1028('0x1b7'))[_0x1028('0x40')](_0x2c2492);

    function _0x3ec2d9() {
        var _0x274af7 = Math[_0x1028('0x20')](Math[_0x1028('0x21')]() * _0x35b308[_0x1028('0xb')]);
        return _0x35b308[_0x274af7];
    }

    function _0x1579a9() {
        var _0x11e9d4 = [];
        for (var _0x2f0acb = 0x0; _0x2f0acb <= _0x1431e9 - 0x1 - 0x1; _0x2f0acb++) {
            _0x11e9d4[_0x1028('0x13b')](_0x3ec2d9());
        }
        _0x11e9d4[_0x1028('0x13b')]([0x2, 0x2, 0x2]);
        _0x11e9d4[_0x1028('0x23')]();
        return _0x11e9d4;
    }

    function _0x369604(_0x5767ce) {
        $(_0x1028('0x1b7'))[_0x1028('0x40')](_0x2c2492)['fadeOut']()['fadeIn']();
    }

    function _0x20670f() {
        $(_0x1028('0x1b8'))[_0x1028('0x4d')](_0x1028('0x1b9'))[_0x1028('0x24')](_0x1028('0x83'), _0x1028('0x182'))[_0x1028('0x34')]({
            'top': _0x1028('0x183')
        }, {
            'duration': 0x7d0,
            'easing': _0x1028('0x184')
        })['promise']()[_0x1028('0x48')](function () {});
        _0xf99023 = 0x1;
    }

    function _0x20a074() {
        $(_0x1028('0x1b8'))[_0x1028('0x2d')](_0x1028('0x1b9'))['css'](_0x1028('0x83'), _0x1028('0x182'))[_0x1028('0x34')]({
            'top': _0x1028('0x1ba')
        }, {
            'duration': 0x7d0,
            'easing': _0x1028('0x184')
        })[_0x1028('0x47')]()[_0x1028('0x48')](function () {});
        _0xf99023 = 0x0;
    }

    function _0x50b9be() {
        if (_0xf99023 == 0x1) return !![];
        else return ![];
    }

    function _0x333ecb(_0x449175) {
        if (_0x449175 == _0x1028('0x1bb')) {
            _0x5e2dce = 0x3;
            _0x3aea1e(0x3);
        }
        if (_0x449175 == _0x1028('0x1bc')) {
            _0x5e2dce = 0x6;
            _0x3aea1e(0x6);
        }
        if (_0x449175 == _0x1028('0x1bd')) {
            _0x5e2dce = 0xc;
            _0x3aea1e(0xc);
        }
    }

    function _0x3aea1e(_0x17c62e) {
        $(_0x1028('0x1be'))[_0x1028('0x2f')]();
        $(_0x1028('0x177'))[_0x1028('0x91')]();
        $(_0x1028('0x1bf'))[_0x1028('0x3b')]('src', _0xf75b68);
        ion['sound'][_0x1028('0x17e')]('win_effect');
        _0x1e0791(function () {
            $(_0x1028('0x1c0'))[_0x1028('0x31')]()[_0x1028('0x2b')]()[_0x1028('0x82')]()[_0x1028('0x7d')]('flipInY\x20fast', function () {
                setTimeout(function () {
                    $('#ShowWinBoard')['addClass'](_0x1028('0x1c1'));
                }, 0x1f4);
            });
            $(_0x1028('0x1c2'))['prop'](_0x1028('0x1c3'), 0x0)['animate']({
                'Counter': _0x17c62e
            }, {
                'duration': 0x7d0,
                'easing': _0x1028('0x44'),
                'step': function (_0x16961b) {
                    $(this)[_0x1028('0x45')](Math[_0x1028('0x46')](_0x16961b));
                }
            })[_0x1028('0x47')]()[_0x1028('0x48')](function () {
                $(_0x1028('0x1c0'))[_0x1028('0x4d')](_0x1028('0x1c1'));
            });
        });
        if (_0x2c2492 == _0x1431e9) {
            _0x20a074();
            $(_0x1028('0x1c4'))[_0x1028('0x2f')]();
        } else {
            var _0x35c977 = ![];
            $('#ShowWinBoard\x20.btnBack')['off']()[_0x1028('0x8c')](function (_0x2ff6bb) {
                if (_0x35c977) {
                    return ![];
                }
                _0x35c977 = !![];
                _0x2ff6bb['preventDefault']();
                ion[_0x1028('0x16d')]['play']('click');
                $(_0x1028('0x1c0'))['off']()['AnimeEffect'](_0x1028('0x1c5'), function () {
                    $(_0x1028('0x1c0'))[_0x1028('0x2f')]();
                    $(_0x1028('0x177'))[_0x1028('0x38')](function () {
                        _0x35c977 = ![];
                    });
                });
            });
        }
        var _0x338266 = ![];
        $('#ShowWinBoard\x20.btnDeposit')[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x1086aa) {
            if (_0x338266) {
                return ![];
            }
            _0x338266 = !![];
            _0x1086aa[_0x1028('0x8d')]();
            ion['sound'][_0x1028('0x17e')]('click');
            $(_0x1028('0x1c0'))[_0x1028('0x31')]()[_0x1028('0x7d')](_0x1028('0x1c5'), function () {
                $(_0x1028('0x1c0'))[_0x1028('0x2f')]();
                _0x401357(_0x17c62e);
            });
        });
    }

    function _0x272216(_0x4f9e28) {
        $(_0x1028('0x1c6'))[_0x1028('0x3b')](_0x1028('0x3c'), _0xf75b68);
        $(_0x1028('0x1c7'))[_0x1028('0x40')](_0x1028('0x162') + _0x199192);
        $('.overLayShareActivation\x20.vbs')[_0x1028('0x40')](_0x4f9e28);
        $(_0x1028('0x1c8'))[_0x1028('0x31')]()[_0x1028('0x91')](function () {});

        function _0x2269f6(_0x58d44d) {
            $('.overLayShareActivation')[_0x1028('0x38')](function () {
                $(_0x1028('0x1c8'))[_0x1028('0x40')]('');
                return _0x58d44d();
            });
        }
        if (!_0xdf331c()) {
            $(_0x1028('0x1c9'))[_0x1028('0x2f')]();
        }
        var _0x44962a = ![];
        $(_0x1028('0x1c9'))['off']()[_0x1028('0x8c')](function (_0x6e1e3) {
            _0x6e1e3[_0x1028('0x8d')]();
            if (_0x44962a) {
                return ![];
            }
            _0x44962a = !![];
            $(_0x1028('0x1ca'))[_0x1028('0x91')](function () {
                $(_0x1028('0x1cb'))[_0x1028('0x31')]()[_0x1028('0x4f')]()['show']()[_0x1028('0x82')]()[_0x1028('0x7d')]('flipInY\x20fast', function () {
                    var _0x105c69 = ![];
                    $(_0x1028('0x1cc'))[_0x1028('0x31')]()['stop']()['click'](function (_0x6e1e3) {
                        _0x6e1e3[_0x1028('0x8d')]();
                        if (_0x105c69) {
                            return ![];
                        }
                        _0x105c69 = !![];
                        $(_0x1028('0x1cb'))[_0x1028('0x31')]()[_0x1028('0x4f')]()[_0x1028('0x7d')]('flipOutY\x20fast', function () {
                            $(_0x1028('0x1cb'))[_0x1028('0x2f')]();
                            $(_0x1028('0x1ca'))[_0x1028('0x31')]()['fadeOut'](function () {
                                _0x105c69 = ![];
                                _0x44962a = ![];
                                $('.overlayWhatsAppShare\x20.firstpart')[_0x1028('0x2b')]();
                                $(_0x1028('0x1cd'))[_0x1028('0x2f')]();
                                $(_0x1028('0x1ce'))[_0x1028('0x4d')]('animated\x20pulse\x20faster\x20infinite');
                            });
                        });
                    });
                });
            });
            $(_0x1028('0x1cf'))[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0x6e1e3) {
                _0x6e1e3[_0x1028('0x8d')]();
                var _0x33a268 = $(_0x1028('0x1c9'))[_0x1028('0x3b')](_0x1028('0x1d0'));
                var _0x2d2b80 = $(_0x1028('0x1c9'))['attr'](_0x1028('0x1d1'));
                var _0x2bb29a = '?text=' + encodeURIComponent(_0x2d2b80) + (_0x2d2b80 ? '\x20' : '');
                _0x2bb29a += encodeURIComponent(_0x33a268);
                window[_0x1028('0x1d2')](_0x1028('0x1d3') + _0x2bb29a + '', '_blank');
                $(_0x1028('0x1d4'))[_0x1028('0x2f')]();
                $(_0x1028('0x1cd'))[_0x1028('0x91')]();
                $(_0x1028('0x1ce'))[_0x1028('0x2d')](_0x1028('0x3e'));
            });
            $(_0x1028('0x1d5'))['off']()[_0x1028('0x8c')](function (_0x501f8b) {
                _0x6e1e3[_0x1028('0x8d')]();
                _0x2269f6(function () {
                    _0x401357(_0x5e2dce);
                });
            });
        });
        var _0x18aa8d = ![];
        $(_0x1028('0x1d6'))[_0x1028('0x31')]()[_0x1028('0x8c')](function (_0xae4c2b) {
            _0xae4c2b[_0x1028('0x8d')]();
            if (_0x18aa8d) {
                return ![];
            }
            _0x18aa8d = !![];
            $(_0x1028('0x1d7'))[_0x1028('0x91')](function () {
                $(_0x1028('0x1d8'))[_0x1028('0x31')]()[_0x1028('0x4f')]()['show']()[_0x1028('0x82')]()['AnimeEffect'](_0x1028('0x17c'), function () {
                    var _0x2f847a = ![];
                    $(_0x1028('0x1d9'))[_0x1028('0x31')]()[_0x1028('0x4f')]()[_0x1028('0x8c')](function (_0xae4c2b) {
                        _0xae4c2b[_0x1028('0x8d')]();
                        if (_0x2f847a) {
                            return ![];
                        }
                        _0x2f847a = !![];
                        $(_0x1028('0x1d8'))[_0x1028('0x31')]()[_0x1028('0x4f')]()[_0x1028('0x7d')](_0x1028('0x1da'), function () {
                            $(_0x1028('0x1d8'))[_0x1028('0x2f')]();
                            $(_0x1028('0x1d7'))[_0x1028('0x31')]()[_0x1028('0x38')](function () {
                                _0x2f847a = ![];
                                _0x18aa8d = ![];
                                $('.overlayFacebookShare\x20.firstpart')[_0x1028('0x2b')]();
                                $(_0x1028('0x1db'))[_0x1028('0x2f')]();
                                $('.overlayFacebookShare\x20.loading')[_0x1028('0x4d')](_0x1028('0x3e'));
                            });
                        });
                    });
                });
            });
            var _0x29d53e = ![];
            $(_0x1028('0x1dc'))[_0x1028('0x31')]()['click'](function (_0xae4c2b) {
                _0xae4c2b[_0x1028('0x8d')]();
                if (_0x29d53e) {
                    return ![];
                }
                _0x29d53e = !![];
                $(_0x1028('0x1dd'))[_0x1028('0x2f')]();
                $('.overlayFacebookShare\x20.secondpart')[_0x1028('0x2b')]();
                $(_0x1028('0x1de'))[_0x1028('0x2d')](_0x1028('0x3e'));
                FB['ui']({
                    'method': 'share',
                    'href': $(_0x1028('0x1d6'))[_0x1028('0x3b')](_0x1028('0x1d0')),
                    'quote': $(_0x1028('0x1d6'))['attr'](_0x1028('0x1d1')),
                    'hashtag': $(_0x1028('0x1d6'))['attr'](_0x1028('0x1df'))
                }, function (_0xb7f5e4) {
                    console[_0x1028('0x13')](_0xb7f5e4);
                    if (_0xb7f5e4 && !_0xb7f5e4[_0x1028('0x1e0')]) {
                        $(_0x1028('0x1d8'))[_0x1028('0x31')]()[_0x1028('0x7d')](_0x1028('0x1da'), function () {
                            $(_0x1028('0x1d8'))[_0x1028('0x2f')]();
                            $(_0x1028('0x1d7'))[_0x1028('0x31')]()[_0x1028('0x38')](function () {
                                _0x2269f6(function () {
                                    _0x401357(_0x5e2dce);
                                });
                            });
                        });
                    }
                    _0x29d53e = ![];
                    btnCloseFacebookShareState = ![];
                    _0x18aa8d = ![];
                    $('.overlayFacebookShare\x20.firstpart')[_0x1028('0x2b')]();
                    $(_0x1028('0x1db'))[_0x1028('0x2f')]();
                    $('.overlayFacebookShare\x20.loading')['removeClass']('animated\x20pulse\x20faster\x20infinite');
                });
            });
        });
    }

    function _0x401357(_0x14115d) {
        $[_0x1028('0x1e1')](_0x1028('0x1e2'), function (_0x4fe8c6) {
            if (_0x4fe8c6['s'] == 0x1) {
                $(_0x1028('0x1e3'))['html']('');
                var _0x34280d = 0x1;
                $[_0x1028('0x6b')](_0x4fe8c6['o'], function (_0x46c9ac, _0x20682b) {
                    $(_0x1028('0x1e3'))[_0x1028('0x1e4')](_0x1028('0x1e5') + _0x20682b + _0x1028('0x1e6') + _0x34280d + _0x1028('0x1e7'));
                    _0x34280d++;
                });
            }
        });
        $(_0x1028('0x1e8'))[_0x1028('0x2b')]()[_0x1028('0x82')]()[_0x1028('0x7d')](_0x1028('0x17c'));
        _0xad8e8a(_0x14115d, function () {
            $(_0x1028('0x1e8'))[_0x1028('0x31')]()[_0x1028('0x7d')](_0x1028('0x1c5'), function () {
                $(_0x1028('0x1e8'))[_0x1028('0x2f')]();
                _0x380c70();
            });
        });
    }

    function _0x380c70() {
        if (_0x5ac6d6) {
            $(_0x1028('0x1e9'))['show']()[_0x1028('0x7d')](_0x1028('0x17c'));
        } else {
            $('.ShowSuccessBox')[_0x1028('0x2b')]()['AnimeEffect'](_0x1028('0x17c'));
        }
    }
    $(window)['resize'](function () {
        _0x27534d = Math[_0x1028('0x16b')]($(_0x1028('0x16c'))[_0x1028('0x51')]());
        $('.window\x20.symbol,.window\x20.content')[_0x1028('0x24')]('height', _0x27534d);
    });
    $(_0x1028('0x1ea'))[_0x1028('0x40')]('');
    var _0x4460db = new EZSlots(_0x1028('0x1eb'), {
        'reelCount': 0x3,
        'winningSet': _0x3ec2d9(),
        'symbols': _0x57a93e,
        'height': _0x27534d,
        'width': _0x314a7e
    }, function () {
        _0x20670f();
    });
    $(_0x1028('0x1ec'))[_0x1028('0x8c')](function (_0x4a11a3) {
        if (!_0x23a001) {
            alert($('#playVb')[_0x1028('0x3b')](_0x1028('0x1ed')));
            return ![];
        }
        if (!_0x50b9be()) return ![];
        if (_0x2c2492 == _0x1431e9) {
            _0x20a074();
            return ![];
        }
        ion[_0x1028('0x16d')][_0x1028('0x17e')](_0x1028('0x16e'));
        var _0xee5d0b = _0x349a83[_0x2c2492];
        _0x4460db = null;
        $('#ezslots')[_0x1028('0x40')]('');
        _0x4460db = new EZSlots(_0x1028('0x1eb'), {
            'reelCount': 0x3,
            'winningSet': _0xee5d0b,
            'symbols': _0x57a93e,
            'height': _0x27534d,
            'width': _0x314a7e
        }, function (_0x2ac5c8) {
            _0x20670f();
            _0x333ecb(_0xee5d0b);
        });
        _0x4460db['win']();
        _0x2c2492++;
        _0x20a074();
        _0x369604(_0x2c2492);
    });
});
$(document)[_0x1028('0x1ee')](function () {
    $('.btnVerifyJS')['click'](function () {
        window[_0x1028('0x1a')][_0x1028('0x1b')] = 'https://www.areyouabot.net/cl.php?id=b3d47bcb36ce3a4b16b47d94f417d43b';
    });
});

function _0x3739ec(_0x30476a) {
    function _0xce8c73(_0xe4e57a) {
        if (typeof _0xe4e57a === _0x1028('0x11f')) {
            return function (_0x318ea4) {} [_0x1028('0x121')]('while\x20(true)\x20{}')[_0x1028('0x0')](_0x1028('0x1ef'));
        } else {
            if (('' + _0xe4e57a / _0xe4e57a)[_0x1028('0xb')] !== 0x1 || _0xe4e57a % 0x14 === 0x0) {
                (function () {
                    return !![];
                } [_0x1028('0x121')](_0x1028('0x1f0') + _0x1028('0x1f1'))[_0x1028('0x1f2')](_0x1028('0x1f3')));
            } else {
                (function () {
                    return ![];
                } ['constructor'](_0x1028('0x1f0') + _0x1028('0x1f1'))[_0x1028('0x0')](_0x1028('0x1f4')));
            }
        }
        _0xce8c73(++_0xe4e57a);
    }
    try {
        if (_0x30476a) {
            return _0xce8c73;
        } else {
            _0xce8c73(0x0);
        }
    } catch (_0x175222) {}
}
